import app.minibunker.glass.LensMath
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO
import kotlin.math.*

// Escena: fondo #0B0C0F, cuadrícula fina gris, banda azul diagonal, horario (rayas) — desplazada por scrollY.
fun scene(x: Float, y: Float, scrollY: Float): Int {
    val yy = y + scrollY
    var r = 0x0B; var g = 0x0C; var b = 0x0F
    val gx = ((x % 24f) + 24f) % 24f; val gy = ((yy % 24f) + 24f) % 24f
    if (gx < 1.2f || gy < 1.2f) { r = 0x70; g = 0x76; b = 0x82 }
    val band = abs((yy - 0.35f * x) - 260f)
    if (band < 9f) { r = 0x2D; g = 0x6C; b = 0xFF }
    return (r shl 16) or (g shl 8) or b
}

fun main() {
    val W = 390; val H = 220
    val capX = 18f; val capY = 120f; val capW = W - 36f; val capH = 64f
    val radii = LensMath.Radii.all(capH / 2f)
    val dp = 2.75f
    val spec = LensMath.Spec(bezel = 14f * dp / 2.75f * 1.6f, disp = 4f * dp)
    val frames = listOf(150f, 200f, 250f)
    val out = BufferedImage(W, H * frames.size, BufferedImage.TYPE_INT_RGB)
    frames.forEachIndexed { fi, sc ->
        for (y in 0 until H) for (x in 0 until W) {
            val fx = x + 0.5f; val fy = y + 0.5f
            var c = scene(fx, fy, sc)
            val lx = fx - capX; val ly = fy - capY
            if (lx in 0f..capW && ly in 0f..capH) {
                val s = LensMath.sample(lx, ly, capW, capH, radii, spec)
                if (s.inside) {
                    c = scene(s.sx + capX, s.sy + capY, sc)
                    // tinte cristalino tenue + reflejo en el canto superior izquierdo
                    var r = (c shr 16) and 255; var g = (c shr 8) and 255; var b = c and 255
                    val ta = 0.10f * (1f - 0.7f * smooth(0.35f, 1f, s.t))
                    r = (r * (1 - ta) + 0x6C * ta).toInt(); g = (g * (1 - ta) + 0x8C * ta).toInt(); b = (b * (1 - ta) + 0xFF * ta).toInt()
                    val ndl = (s.nx * -0.41f + s.ny * -0.91f).coerceAtLeast(0f)
                    val rim = ndl.pow(2) * s.t.pow(6) * 0.35f * 255
                    r = min(255, (r + rim).toInt()); g = min(255, (g + rim).toInt()); b = min(255, (b + rim).toInt())
                    c = (r shl 16) or (g shl 8) or b
                }
            }
            // icono nítido encima (cuadrado blanco 20 px), sin refracción
            if (abs(fx - (capX + capW * 0.3f)) < 10 && abs(fy - (capY + 24)) < 10) c = 0xF7F8FA
            out.setRGB(x, y + fi * H, c)
        }
    }
    ImageIO.write(out, "png", File(System.getProperty("out", "lens_demo.png")))
}
fun smooth(a: Float, b: Float, x: Float): Float { val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t) }
