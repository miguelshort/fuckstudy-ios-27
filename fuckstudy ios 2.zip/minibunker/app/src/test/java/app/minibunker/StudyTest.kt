package app.minibunker

import app.minibunker.study.*
import app.thinktwice.core.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class StudyTest {
    private val madrid = ZoneId.of("Europe/Madrid")
    private fun at(s: String) = LocalDateTime.parse(s).atZone(madrid).toInstant().toEpochMilli()
    private val ig = "com.instagram.android"
    private val tk = "com.zhiliaoapp.musically"
    private var n = 0
    private val ids = { "b${n++}" }
    private val min = 60_000L

    private fun start(t: Long, protect: Boolean = true) =
        StudyEngine.start("s1", "Geografía", "p1", "Relieve", PomoPrefs(), protect, setOf(ig, tk), t)

    @Test fun indicatorText() {
        val t = at("2026-11-19T17:00")
        val r = start(t)
        assertEquals("Geografía · 25:00 · 2 apps protegidas", StudyEngine.indicator(r, t, true))
        assertEquals("Geografía · 24:59 · 2 apps protegidas", StudyEngine.indicator(r, t + 1000, true))
        assertEquals("Geografía · 25:00 · protección no operativa", StudyEngine.indicator(r, t, false))
        assertEquals("General · 25:00 · sin protección", StudyEngine.indicator(start(t, false).copy(subject = ""), t, true))
    }

    @Test fun pauseSuspendsOnlyLinkedProtectionAndResumeAppliesRemaining() {
        val t0 = at("2026-11-19T17:00")
        var r = start(t0)
        var sessions = StudyEngine.reconcileProtection(r, emptyList(), t0, ids)
        var st = AppState(sessions = sessions)
        assertTrue(RuleEngine.decide(st, ig, t0 + 5 * min, madrid) is Decision.Block)
        // Pausa a los 10 min: la app queda libre.
        r = StudyEngine.pause(r, t0 + 10 * min)
        sessions = StudyEngine.reconcileProtection(r, sessions, t0 + 10 * min, ids)
        st = AppState(sessions = sessions)
        assertEquals(Decision.Allow, RuleEngine.decide(st, ig, t0 + 12 * min, madrid))
        assertEquals(15 * min, r.leftMs)
        // Reanuda a los 20 min: protegida por los 15 que quedan.
        r = StudyEngine.resume(r, t0 + 20 * min)
        sessions = StudyEngine.reconcileProtection(r, sessions, t0 + 20 * min, ids)
        st = AppState(sessions = sessions)
        val d = RuleEngine.decide(st, ig, t0 + 21 * min, madrid) as Decision.Block
        assertEquals(t0 + 35 * min, d.untilMs)
        // Llamar otra vez no crea otra sesión.
        assertEquals(sessions, StudyEngine.reconcileProtection(r, sessions, t0 + 21 * min, ids))
        // La pausa no cuenta como salida de emergencia ni como sesión completada.
        assertTrue(sessions.none { it.endedEarlyAtMs != null })
        assertEquals(1, sessions.count { it.suspendedAtMs != null })
    }

    @Test fun breakRemovesProtectionAndTimeIsCountedOnce() {
        val t0 = at("2026-11-19T17:00")
        var r = start(t0)
        // Pantalla bloqueada: el bloque termina sin que la app esté abierta; al volver se calcula.
        r = StudyEngine.tick(r, t0 + 26 * min)
        assertEquals(Phase.SHORT, r.phase)
        assertEquals(1, r.cycle)
        assertEquals(25 * min, r.focusMs)
        val rec1 = StudyEngine.record(r)!!
        // Descanso de 5 min: sin protección.
        r = StudyEngine.resume(r, t0 + 27 * min)
        val ss = StudyEngine.reconcileProtection(r, emptyList(), t0 + 27 * min, ids)
        assertEquals(Decision.Allow, RuleEngine.decide(AppState(sessions = ss), ig, t0 + 28 * min, madrid))
        r = StudyEngine.finish(r, t0 + 29 * min)
        val rec2 = StudyEngine.record(r)!!
        // Mismo id y mismos minutos: se guarda una sola sesión de 25 min, no 50.
        assertEquals(rec1.id, rec2.id)
        assertEquals(25, rec2.mins)
    }

    @Test fun lessThanAMinuteIsNotSaved() {
        val t0 = at("2026-11-19T17:00")
        assertNull(StudyEngine.record(StudyEngine.finish(start(t0), t0 + 40_000)))
        assertEquals(12, StudyEngine.record(StudyEngine.finish(start(t0), t0 + 12 * min + 10_000))!!.mins)
    }

    @Test fun longBreakAfterFourBlocks() {
        var t = at("2026-11-19T09:00")
        var r = start(t)
        repeat(4) { i ->
            t = r.endAt; r = StudyEngine.tick(r, t)
            assertEquals(if (i == 3) Phase.LONG else Phase.SHORT, r.phase)
            r = StudyEngine.resume(r, t); t = r.endAt; r = StudyEngine.tick(r, t)
            assertEquals(Phase.FOCUS, r.phase)
            r = StudyEngine.resume(r, t)
        }
        assertEquals(4, r.cycle)
        assertEquals(100 * min, r.focusMs)
    }

    @Test fun studyOverlappingNightRoutineKeepsRoutineEnd() {
        // Rutina nocturna 22:00–07:00 con la misma app; estudio de 21:50 a 22:15.
        val night = Routine("n", "Noche", setOf(ig), 22 * 60, 7 * 60, (1..7).toSet(), true)
        val t0 = at("2026-11-19T21:50")
        var r = start(t0)
        var sessions = StudyEngine.reconcileProtection(r, emptyList(), t0, ids)
        var st = AppState(routines = listOf(night), sessions = sessions)
        assertEquals(at("2026-11-20T07:00"), (RuleEngine.decide(st, ig, t0 + min, madrid) as Decision.Block).untilMs)
        // Termina el estudio a las 22:05: la rutina sigue hasta las 07:00.
        val tEnd = at("2026-11-19T22:05")
        r = StudyEngine.finish(r, tEnd)
        sessions = StudyEngine.reconcileProtection(null, sessions, tEnd, ids)
        st = AppState(routines = listOf(night), sessions = sessions)
        val d = RuleEngine.decide(st, ig, tEnd + min, madrid) as Decision.Block
        assertEquals(at("2026-11-20T07:00"), d.untilMs)
        assertEquals(listOf(Restriction.Kind.ROUTINE), d.sources.map { it.kind })
        // Una app protegida solo por el estudio queda libre.
        assertEquals(Decision.Allow, RuleEngine.decide(st, tk, tEnd + min, madrid))
    }

    @Test fun emergencyExitLetsStudyContinueWithoutReprotecting() {
        val t0 = at("2026-11-19T17:00")
        var r = start(t0)
        var sessions = StudyEngine.reconcileProtection(r, emptyList(), t0, ids)
        sessions = sessions.map { it.copy(endedEarlyAtMs = t0 + 3 * min) } // salida de emergencia
        assertTrue(StudyEngine.emergencyUsed(r, sessions))
        r = r.copy(protectionStopped = true)
        r = StudyEngine.pause(r, t0 + 5 * min); r = StudyEngine.resume(r, t0 + 6 * min)
        sessions = StudyEngine.reconcileProtection(r, sessions, t0 + 6 * min, ids)
        assertEquals(Decision.Allow, RuleEngine.decide(AppState(sessions = sessions), ig, t0 + 7 * min, madrid))
        assertTrue(r.running)
    }

    @Test fun blockBeatsPauseAllowance() {
        val t0 = at("2026-11-19T17:00")
        val r = start(t0)
        val st = AppState(pausedApps = setOf(ig), allowances = mapOf(ig to t0 + 30 * min),
            sessions = StudyEngine.reconcileProtection(r, emptyList(), t0, ids))
        assertTrue(RuleEngine.decide(st, ig, t0 + min, madrid) is Decision.Block)
    }

    @Test fun runSurvivesSerialization() {
        val r = StudyEngine.pause(start(at("2026-11-19T17:00")), at("2026-11-19T17:07"))
        assertEquals(r, StudyRun.from(app.minibunker.json.Json.obj(app.minibunker.json.Json.write(r.toJson()))))
    }

    @Test fun sphereLevelFollowsTheSameTimer() {
        val t = at("2026-11-19T17:00")
        var r = start(t)
        assertEquals(1.0, StudyEngine.sphereLevel(r, t).toDouble(), 1e-6)                       // 25:00 llena
        assertEquals(0.5, StudyEngine.sphereLevel(r, t + 12 * min + 30_000).toDouble(), 1e-6) // 12:30 cruza el centro
        assertEquals(0.0, StudyEngine.sphereLevel(r, t + 25 * min).toDouble(), 1e-6)            // 00:00 vacía
        // En pausa se congela con el número; al reanudar siguen juntos.
        r = StudyEngine.pause(r, t + 10 * min)
        val frozen = StudyEngine.sphereLevel(r, t + 10 * min)
        assertEquals(frozen.toDouble(), StudyEngine.sphereLevel(r, t + 40 * min).toDouble(), 1e-6)
        assertEquals(0.6, frozen.toDouble(), 1e-6)
        r = StudyEngine.resume(r, t + 40 * min)
        assertEquals(0.6, StudyEngine.sphereLevel(r, t + 40 * min).toDouble(), 1e-6)
        assertEquals("Geografía · 15:00 · 2 apps protegidas", StudyEngine.indicator(r, t + 40 * min, true))
    }
}
