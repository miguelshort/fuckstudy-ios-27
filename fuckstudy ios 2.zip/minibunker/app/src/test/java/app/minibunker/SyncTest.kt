package app.minibunker

import app.minibunker.academic.*
import app.minibunker.cloud.AcademicRemote
import app.minibunker.cloud.RemoteDoc
import app.minibunker.json.*
import org.junit.Assert.*
import org.junit.Test

/** Servidor falso con versiones, para probar la fusión y las condiciones de escritura sin red. */
class FakeRemote : AcademicRemote {
    val docs = HashMap<String, Pair<JObj, Int>>()
    var writes = 0
    /** Simula que otro dispositivo escribe justo antes de nuestra próxima escritura. */
    var interleave: (() -> Unit)? = null
    var offline = false

    private fun check() { if (offline) throw app.minibunker.cloud.NetworkException() }
    override fun get(doc: String): RemoteDoc? { check(); return docs[doc]?.let { RemoteDoc(it.first, "v${it.second}") } }
    override fun getMany(docs: List<String>) = docs.associateWith { get(it) }
    override fun put(doc: String, value: JObj, expectedUpdateTime: String?): Boolean {
        check()
        interleave?.let { interleave = null; it() }
        val cur = docs[doc]
        val curV = cur?.let { "v${it.second}" }
        if (curV != expectedUpdateTime) return false
        docs[doc] = Json.obj(Json.write(value)) to ((cur?.second ?: 0) + 1)
        writes++
        return true
    }
    override fun putUnconditional(doc: String, value: JObj) { docs[doc] = value to ((docs[doc]?.second ?: 0) + 1) }
    override fun delete(doc: String) { docs.remove(doc) }
    fun items(part: Part) = docs[part.key]?.first?.objs("items").orEmpty()
    fun seed(part: Part, items: List<JObj>) { docs[part.key] = linkedMapOf("items" to items, "updated" to 1L) to 1 }
}

class SyncTest {
    private fun grade(id: String, subject: String, score: Double? = null) = Grade(id, subject, "Tema 1", "2026-12-01", score = score).toJson()

    @Test fun jsonRoundTripKeepsWebShape() {
        val text = """{"items":[{"id":"a","subject":"Geografía","score":7.5,"max":10,"weight":null,"days":{"2026-11-19":1}}],"updated":1732000000000}"""
        val o = Json.obj(text)
        assertEquals(text, Json.write(o))
        val g = Grade.from(o.objs("items")[0])
        assertEquals(7.5, g.score!!, 0.0)
        assertNull(g.weight)
    }

    @Test fun existingAccountIsReadAsIs() {
        val r = FakeRemote()
        r.seed(Part.GRADES, listOf(grade("g1", "Historia", 8.0)))
        r.seed(Part.TIMETABLE, listOf(ClassEntry("c1", 1, "08:00", "09:00", "s1", "Mates").toJson()))
        val core = SyncCore()
        SyncEngine.pull(core, r)
        val a = Academic(core.view())
        assertEquals("Historia", a.grades.single().subject)
        assertEquals("Mates", a.timetable.single().subject)
        assertEquals(0, core.pendingCount())
    }

    @Test fun offlineEditProducesSingleChangeAfterSync() {
        val r = FakeRemote()
        r.seed(Part.GRADES, listOf(grade("g1", "Geografía"), grade("g2", "Historia")))
        val core = SyncCore()
        SyncEngine.pull(core, r)
        r.offline = true
        // Editar el examen sin conexión dos veces: un único cambio pendiente.
        core.mutate(Part.GRADES) { l -> l.map { if (it.str("id") == "g1") LinkedHashMap(it).apply { put("title", "Tema 2") } else it } }
        core.mutate(Part.GRADES) { l -> l.map { if (it.str("id") == "g1") LinkedHashMap(it).apply { put("title", "Tema 3") } else it } }
        assertEquals(1, core.pendingCount())
        assertEquals("Tema 3", Academic(core.view()).grades.first { it.id == "g1" }.title)
        try { SyncEngine.pushAll(core, r); fail() } catch (e: app.minibunker.cloud.NetworkException) {}
        assertEquals(1, core.pendingCount())
        r.offline = false
        assertTrue(SyncEngine.pushAll(core, r))
        assertEquals(0, core.pendingCount())
        assertEquals(1, r.writes)
        val remote = r.items(Part.GRADES)
        assertEquals(2, remote.size)
        assertEquals("Tema 3", remote.first { it.str("id") == "g1" }.str("title"))
        // Reintentar no duplica nada.
        assertTrue(SyncEngine.pushAll(core, r))
        assertEquals(1, r.writes)
    }

    @Test fun concurrentWriteFromOtherDeviceIsMergedNotLost() {
        val r = FakeRemote()
        r.seed(Part.NOTES, listOf(Note("n1", "Compra").toJson()))
        val core = SyncCore()
        SyncEngine.pull(core, r)
        core.mutate(Part.NOTES) { it + Note("n2", "Local").toJson() }
        // Otro dispositivo añade n3 entre nuestra lectura y nuestra escritura.
        r.interleave = { r.docs[Part.NOTES.key] = linkedMapOf<String, Any?>("items" to r.items(Part.NOTES) + Note("n3", "Web").toJson()) to 7 }
        assertTrue(SyncEngine.pushPart(core, r, Part.NOTES))
        assertEquals(setOf("n1", "n2", "n3"), r.items(Part.NOTES).map { it.str("id") }.toSet())
        assertEquals(setOf("n1", "n2", "n3"), Academic(core.view()).notes.map { it.id }.toSet())
    }

    @Test fun deleteOnlyRemovesThatItem() {
        val r = FakeRemote()
        r.seed(Part.HABITS, listOf(Habit("h1", "Leer").toJson(), Habit("h2", "Correr").toJson()))
        val core = SyncCore(); SyncEngine.pull(core, r)
        core.mutate(Part.HABITS) { l -> l.filter { it.str("id") != "h1" } }
        r.seed(Part.HABITS, r.items(Part.HABITS) + Habit("h3", "Agua").toJson())
        SyncEngine.pushAll(core, r)
        assertEquals(listOf("h2", "h3"), r.items(Part.HABITS).map { it.str("id") })
    }

    @Test fun guestDataIsAddedToAccountWithoutRemovingAnything() {
        val core = SyncCore()
        core.mutate(Part.EVENTS) { it + Event("e1", "2026-11-20", title = "Local").toJson() }
        // Simula que lo local nunca se había subido: base vacía.
        core.promoteAllToPending()
        val r = FakeRemote(); r.seed(Part.EVENTS, listOf(Event("e0", "2026-11-19", title = "Cuenta").toJson()))
        SyncEngine.pull(core, r); SyncEngine.pushAll(core, r)
        assertEquals(listOf("e0", "e1"), r.items(Part.EVENTS).map { it.str("id") })
    }

    @Test fun localEditDuringPushStaysPending() {
        val r = FakeRemote(); r.seed(Part.PLANS, emptyList())
        val core = SyncCore(); SyncEngine.pull(core, r)
        core.mutate(Part.PLANS) { it + PlanItem("p1", "g", "Geo", "Tema 1", "2026-11-20").toJson() }
        r.interleave = { core.mutate(Part.PLANS) { l -> l + PlanItem("p2", "g", "Geo", "Tema 2", "2026-11-21").toJson() } }
        SyncEngine.pushPart(core, r, Part.PLANS)
        assertEquals(1, core.pendingCount())
        assertEquals(listOf("p1", "p2"), Academic(core.view()).plans.map { it.id })
        SyncEngine.pushPart(core, r, Part.PLANS)
        assertEquals(listOf("p1", "p2"), r.items(Part.PLANS).map { it.str("id") })
    }

    @Test fun legacyNoteToneMigratesLikeWeb() {
        assertEquals("light", Note.from(mapOf("id" to "x", "title" to "t", "tone" to "dark"))!!.tone)
        assertEquals("dark", Note.from(mapOf("id" to "x", "title" to "t", "tone" to "dark", "tv" to 2L))!!.tone)
        assertNull(Note.from(mapOf("id" to "x")))
    }
}
