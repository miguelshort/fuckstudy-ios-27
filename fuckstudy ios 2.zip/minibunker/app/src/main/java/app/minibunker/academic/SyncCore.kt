package app.minibunker.academic

import app.minibunker.json.*

/**
 * Cambio pendiente sobre un elemento (identificado por su id dentro de una parte).
 * [item] null = borrado. Los cambios son idempotentes: aplicarlos dos veces da el mismo resultado,
 * así que un reintento tras un corte de red nunca duplica nada.
 */
data class Op(val seq: Long, val part: Part, val id: String, val item: JObj?) {
    fun toJson(): JObj = linkedMapOf("seq" to seq, "part" to part.key, "id" to id, "item" to item)
    companion object {
        fun from(o: JObj): Op? {
            val p = Part.of(o.str("part")) ?: return null
            return Op(o.long("seq"), p, o.str("id").ifEmpty { return null }, o.objOrNull("item"))
        }
    }
}

/**
 * Núcleo de sincronización sin conexión (lógica pura, probada en la JVM).
 *
 *  - [base]: última copia conocida de cada parte en la cuenta.
 *  - [pending]: cola de cambios locales todavía no confirmados por el servidor.
 *  - La vista local es siempre base + cambios pendientes.
 *
 * Al enviar una parte se lee su versión actual del servidor, se aplican encima solo los cambios
 * pendientes de esa parte (por id) y se escribe con una condición de versión. Así un cambio hecho
 * sin conexión no pisa lo que otro dispositivo añadió mientras tanto, y nada se borra salvo que el
 * usuario lo haya borrado.
 */
class SyncCore(
    base: Map<Part, List<JObj>> = emptyMap(),
    pending: List<Op> = emptyList(),
    private var nextSeq: Long = (pending.maxOfOrNull { it.seq } ?: 0L) + 1,
) {
    var base: Map<Part, List<JObj>> = base; private set
    var pending: List<Op> = pending; private set

    @Synchronized fun view(): Map<Part, List<JObj>> = Part.entries.associateWith { p -> apply(base[p].orEmpty(), pending.filter { it.part == p }) }

    @Synchronized fun pendingCount() = pending.size
    @Synchronized fun dirtyParts(): Set<Part> = pending.map { it.part }.toSet()

    /**
     * Aplica un cambio local a una parte: compara la lista antes y después por id y encola solo
     * lo que cambió. Un cambio nuevo sobre el mismo elemento sustituye al anterior pendiente.
     * Devuelve los cambios generados.
     */
    @Synchronized fun mutate(part: Part, transform: (List<JObj>) -> List<JObj>): List<Op> {
        val before = view()[part].orEmpty()
        val after = transform(before)
        val ops = diff(part, before, after)
        enqueue(ops)
        return ops
    }

    @Synchronized fun enqueue(ops: List<Op>) {
        if (ops.isEmpty()) return
        val keys = ops.map { it.part to it.id }.toSet()
        pending = pending.filterNot { (it.part to it.id) in keys } + ops.map { it.copy(seq = nextSeq++) }
    }

    private fun diff(part: Part, before: List<JObj>, after: List<JObj>): List<Op> {
        val b = before.associateBy { it.str("id") }
        val a = after.associateBy { it.str("id") }
        val out = mutableListOf<Op>()
        after.forEach { item ->
            val id = item.str("id"); if (id.isEmpty()) return@forEach
            val old = b[id]
            if (old == null || Json.write(old) != Json.write(item)) out += Op(0, part, id, item)
        }
        before.forEach { item -> val id = item.str("id"); if (id.isNotEmpty() && id !in a) out += Op(0, part, id, null) }
        return out
    }

    /** Llega una copia del servidor: se acepta como base; la vista sigue incluyendo lo pendiente. */
    @Synchronized fun acceptRemote(part: Part, items: List<JObj>) { base = base + (part to items) }

    /** Prepara el envío de una parte sobre la versión remota recién leída. */
    @Synchronized fun preparePush(part: Part, remote: List<JObj>): PushPlan {
        val ops = pending.filter { it.part == part }
        return PushPlan(part, apply(remote, ops), ops.maxOfOrNull { it.seq } ?: 0L)
    }

    /** El servidor confirmó la escritura: la base pasa a ser lo escrito y se retiran esos cambios. */
    @Synchronized fun confirmPush(plan: PushPlan) {
        base = base + (plan.part to plan.merged)
        pending = pending.filterNot { it.part == plan.part && it.seq <= plan.upToSeq }
    }

    /** Todo lo local pasa a pendiente (p. ej. datos usados sin cuenta que se suben al iniciar sesión). */
    @Synchronized fun promoteAllToPending() {
        val v = view()
        base = emptyMap()
        pending = emptyList()
        Part.entries.forEach { p -> enqueue(v[p].orEmpty().filter { it.str("id").isNotEmpty() }.map { Op(0, p, it.str("id"), it) }) }
    }

    @Synchronized fun clear() { base = emptyMap(); pending = emptyList() }

    data class PushPlan(val part: Part, val merged: List<JObj>, val upToSeq: Long)

    companion object {
        /** Aplica cambios por id conservando el orden remoto; los nuevos se añaden al final. */
        fun apply(items: List<JObj>, ops: List<Op>): List<JObj> {
            if (ops.isEmpty()) return items
            val latest = LinkedHashMap<String, Op>()
            ops.sortedBy { it.seq }.forEach { latest[it.id] = it }
            val out = ArrayList<JObj>(items.size + latest.size)
            val seen = HashSet<String>()
            items.forEach { item ->
                val id = item.str("id")
                seen += id
                val op = latest[id]
                when {
                    op == null -> out += item
                    op.item != null -> out += op.item
                    else -> Unit // borrado
                }
            }
            latest.values.forEach { op -> if (op.id !in seen && op.item != null) out += op.item }
            return out
        }
    }
}
