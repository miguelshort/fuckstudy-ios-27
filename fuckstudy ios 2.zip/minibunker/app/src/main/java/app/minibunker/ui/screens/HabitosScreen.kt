package app.minibunker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.minibunker.academic.*
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.theme.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Hábitos: cuarto destino de la cápsula. Crear, marcar y consultar hábitos y rachas.
 * Los apuntes antiguos (Notas) ya no se muestran, pero se conservan en el almacenamiento y en la cuenta.
 */
@Composable
fun HabitosScreen(ac: AcadState) {
    val nav = LocalNav.current
    val a = ac.academic
    var newHabit by rememberSaveable { mutableStateOf("") }
    var delHabit by remember { mutableStateOf<Habit?>(null) }
    val ts = Cal.iso(LocalDate.now())
    val done = a.habits.count { it.done(ts) }

    TabScaffold(
        "Hábitos",
        actions = { Avatar(ac.account?.name.orEmpty()) { nav.profileOpen = true } },
    ) {
        item {
            Text(if (a.habits.isEmpty()) "Pequeñas rutinas que suman cada día" else "$done de ${a.habits.size} hechos hoy", style = Type.secondary)
            Spacer(Modifier.height(12.dp))
            if (a.habits.isNotEmpty()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.related)) {
                TTCard(Modifier.weight(1f), padding = 14.dp) { Text("Hoy", style = Type.label); Text("$done/${a.habits.size}", style = Type.cardFigure) }
                TTCard(Modifier.weight(1f), padding = 14.dp) { Text("Mejor racha", style = Type.label); Text("${a.habits.maxOfOrNull { Cal.streak(it, ts) } ?: 0}", style = Type.cardFigure) }
                TTCard(Modifier.weight(1f), padding = 14.dp) {
                    Text("30 días", style = Type.label)
                    Text("${Math.round(a.habits.sumOf { Cal.last30(it, ts) } * 100.0 / (a.habits.size * 30))} %", style = Type.cardFigure)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                LabeledField("Nuevo hábito", newHabit, { newHabit = it.take(50) }, Modifier.weight(1f), placeholder = "Ej. Leer 20 minutos")
                Spacer(Modifier.width(8.dp))
                PillButton("Crear", { AcademicRepo.edit { Edits.addHabit(it, newHabit) }; nav.show("Hábito creado"); newHabit = "" }, enabled = newHabit.isNotBlank())
            }
            Text("Los hábitos se marcan a mano. Los retos de thinktwice tienen reglas propias medidas por el móvil (sesiones, rutinas o límites de uso).", style = Type.label, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(16.dp))
        }
        if (a.habits.isEmpty()) item { EmptyState(Icons.Rounded.TaskAlt, "Sin hábitos", "Escribe uno arriba para empezar.") }
        else a.habits.forEach { h -> item(key = h.id) { HabitCard(h, ts) { delHabit = h }; Spacer(Modifier.height(Dim.related)) } }
    }
    delHabit?.let { h ->
        ConfirmDialog("Eliminar hábito", "Se borrará «${h.name}» con todo su historial.", "Eliminar",
            onConfirm = { AcademicRepo.edit { Edits.deleteHabit(it, h.id) }; delHabit = null; nav.show("Hábito eliminado") }, onDismiss = { delHabit = null })
    }
}

/** Hábito: marcar hoy, últimos 14 días marcables, racha y cumplimiento de 30 días. */
@Composable
private fun HabitCard(h: Habit, ts: String, onDelete: () -> Unit) {
    val nav = LocalNav.current
    val st = Cal.streak(h, ts)
    val col = hexColor(h.color)
    TTCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CheckCircle(h.done(ts), col, "Hoy: ${h.name}") {
                val was = h.done(ts)
                AcademicRepo.edit { Edits.toggleHabit(it, h.id, ts) }
                if (!was) nav.show("¡Hecho! Racha de ${st + 1} ${if (st + 1 == 1) "día" else "días"}")
            }
            Column(Modifier.weight(1f)) {
                Text(h.name, style = Type.cardTitle, maxLines = 2)
                Text((if (st > 0) "Racha de $st ${if (st == 1) "día" else "días"}" else "Sin racha") + " · ${Cal.last30(h, ts)}/30 días", style = Type.secondary)
            }
            CircleIconButton(Icons.Rounded.Delete, "Eliminar hábito", onDelete, bg = TT.Card)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            (13 downTo 0).forEach { i ->
                val d = Cal.addD(ts, -i.toLong()); val on = h.done(d)
                Box(
                    Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (on) col else TT.Control)
                        .pressable(scaleDown = false, role = Role.Checkbox) { AcademicRepo.edit { Edits.toggleHabit(it, h.id, d) } }
                        .semantics { contentDescription = "${Cal.shortDay(d)}: ${if (on) "hecho" else "sin hacer"}" },
                )
            }
        }
        Text("Últimos 14 días · toca un día para corregirlo", style = Type.label, modifier = Modifier.padding(top = 6.dp))
    }
}

