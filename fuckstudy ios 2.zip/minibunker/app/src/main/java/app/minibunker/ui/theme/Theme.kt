package app.minibunker.ui.theme

import android.app.ActivityManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import app.minibunker.academic.UiPrefs

/** true cuando el usuario ha pedido reducir el movimiento (en el sistema o en fuckstudy). */
val LocalReduceMotion = compositionLocalOf { false }
/** true si el dispositivo puede desenfocar en tiempo real (Android 12+ y sin modo de poca memoria). */
val LocalBlurCapable = compositionLocalOf { false }

@Composable
fun <T> ttTween(ms: Int): FiniteAnimationSpec<T> = if (LocalReduceMotion.current) snap() else tween(ms, easing = FastOutSlowInEasing)

object Themes {
    fun systemDark(c: Context) = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    fun isDark(c: Context, prefs: UiPrefs) = when (prefs.mode) { "claro" -> false; "auto" -> systemDark(c); else -> true }

    /** Recalcula la paleta global a partir de las preferencias y del modo del sistema. */
    fun refresh(c: Context, prefs: UiPrefs) {
        val p = Palettes.of(isDark(c, prefs), prefs.accent)
        if (p != ThemeState.palette) ThemeState.palette = p
        if (ThemeState.glass != prefs.glass) ThemeState.glass = prefs.glass
        val solid = highContrast(c)
        if (ThemeState.solid != solid) ThemeState.solid = solid
    }

    /**
     * Preferencias de contraste de Android: «Texto de alto contraste» y, en Android 14+, el nivel de
     * contraste del sistema. Android no ofrece un ajuste de «reducir transparencia» como iOS; el
     * contraste elevado cumple esa función aquí (base más densa, sin reflejos).
     */
    fun highContrast(c: Context): Boolean {
        val text = runCatching { Settings.Secure.getInt(c.contentResolver, "high_text_contrast_enabled", 0) == 1 }.getOrDefault(false)
        val sys = if (Build.VERSION.SDK_INT >= 34) runCatching {
            (c.getSystemService(Context.UI_MODE_SERVICE) as? android.app.UiModeManager)?.contrast?.let { it >= 0.5f } ?: false
        }.getOrDefault(false) else false
        return text || sys
    }

    fun blurCapable(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        val am = c.getSystemService(ActivityManager::class.java)
        // Equipos de poca memoria: superficie más opaca del mismo tono en lugar de desenfoque.
        return am?.isLowRamDevice != true
    }
}

@Composable
fun MinibunkerTheme(reduceMotionPref: Boolean? = null, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val systemReduced = remember { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }
    val blur = remember { Themes.blurCapable(ctx) }
    val p = ThemeState.palette
    val scheme = if (p.dark) darkColorScheme(
        primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text,
        surface = p.surface, onSurface = p.text, surfaceVariant = p.card, onSurfaceVariant = p.textSecondary,
        surfaceContainer = p.card, surfaceContainerHigh = p.control, surfaceContainerHighest = p.control, surfaceContainerLow = p.surface,
        secondaryContainer = p.control, onSecondaryContainer = p.text, error = p.danger, outline = p.control, outlineVariant = p.divider,
    ) else lightColorScheme(
        primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text,
        surface = p.surface, onSurface = p.text, surfaceVariant = p.card, onSurfaceVariant = p.textSecondary,
        surfaceContainer = p.card, surfaceContainerHigh = p.control, surfaceContainerHighest = p.control, surfaceContainerLow = p.surface,
        secondaryContainer = p.control, onSecondaryContainer = p.text, error = p.danger, outline = p.control, outlineVariant = p.divider,
    )
    val typo = Typography(
        bodyLarge = Type.body, bodyMedium = Type.body.copy(fontSize = Type.secondary.fontSize),
        labelLarge = Type.button, titleLarge = Type.section, headlineMedium = Type.screenTitle,
    )
    val reduce = reduceMotionPref ?: systemReduced
    CompositionLocalProvider(LocalReduceMotion provides reduce, LocalBlurCapable provides blur) {
        MaterialTheme(colorScheme = scheme, typography = typo, content = content)
    }
}
