package app.minibunker.ui.theme

import androidx.compose.ui.graphics.luminance

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.minibunker.R

/**
 * Sistema visual de thinktwice aplicado a todo fuckstudy. El tema oscuro usa exactamente la paleta de
 * thinktwice; el claro y el acento personalizable vienen de MIBUNKER con variantes legibles.
 */
data class Palette(
    val dark: Boolean,
    val bg: Color, val surface: Color, val card: Color, val control: Color,
    val text: Color, val textSecondary: Color,
    val accent: Color, val onAccent: Color, val accentText: Color,
    val positive: Color, val danger: Color, val warm: Color,
    val divider: Color, val scrim: Color, val heroTop: Color,
    /** Tinte de las superficies translúcidas (cápsula, hojas, menús). */
    val glass: Color, val glassOpaque: Color, val glassBorder: Color,
)

object Palettes {
    /** acento → (oscuro, claro). El azul oscuro es el #6C8CFF de thinktwice. */
    private val accents = mapOf(
        "azul" to (Color(0xFF6C8CFF) to Color(0xFF2D5FC7)),
        "lila" to (Color(0xFFA99CF5) to Color(0xFF6B57D4)),
        "rosa" to (Color(0xFFF29CC4) to Color(0xFFB8336F)),
        "verde" to (Color(0xFF65D6A0) to Color(0xFF2A6B57)),
        "turquesa" to (Color(0xFF7FD3D6) to Color(0xFF136C75)),
        "melocoton" to (Color(0xFFF2B48C) to Color(0xFFA24C23)),
        "coral" to (Color(0xFFF59A92) to Color(0xFFB83A36)),
        "dorado" to (Color(0xFFE9CF6B) to Color(0xFF7A5E00)),
    )

    fun of(dark: Boolean, accent: String): Palette {
        val (ad, al) = accents[accent] ?: accents.getValue("azul")
        return if (dark) Palette(
            dark = true,
            bg = Color(0xFF0B0C0F), surface = Color(0xFF15171C), card = Color(0xFF1E2128), control = Color(0xFF292D35),
            text = Color(0xFFF7F8FA), textSecondary = Color(0xFFBFC4CD),
            accent = ad, onAccent = Color(0xFF0B0C0F), accentText = ad,
            positive = Color(0xFF65D6A0), danger = Color(0xFFF26B78), warm = Color(0xFFF2B48C),
            divider = Color(0x14FFFFFF), scrim = Color(0x66000000), heroTop = Color(0xFF151A2B),
            glass = Color(0xB31E2128), glassOpaque = Color(0xF21B1E24), glassBorder = Color(0x1FFFFFFF),
        ) else Palette(
            dark = false,
            bg = Color(0xFFF3F4F7), surface = Color(0xFFFAFAFC), card = Color(0xFFFFFFFF), control = Color(0xFFE7E9EE),
            text = Color(0xFF0E1014), textSecondary = Color(0xFF4A505C),
            accent = al, onAccent = Color(0xFFFFFFFF), accentText = al,
            positive = Color(0xFF1E8A5B), danger = Color(0xFFC7364A), warm = Color(0xFFB4562A),
            divider = Color(0x14000000), scrim = Color(0x47000000), heroTop = Color(0xFFE6EBFA),
            glass = Color(0xB8FFFFFF), glassOpaque = Color(0xF5FBFBFD), glassBorder = Color(0x1A000000),
        )
    }
}

/** Paleta vigente (estado observable: al cambiarla se recompone y se redibuja todo lo que la lee). */
object ThemeState {
    var palette by mutableStateOf(Palettes.of(true, "azul"))
    /** Intensidad del vidrio (Apariencia): 0 = más transparente (valor inicial), 1 = más tintado. */
    var glass by mutableStateOf(0f)
    /**
     * Contraste elevado o transparencia reducida pedidos en Android: superficies con base más
     * densa, sin reflejos ni refracción.
     */
    var solid by mutableStateOf(false)
}

/** Acceso corto a los colores vigentes, también desde lambdas de dibujo. */
object TT {
    val Bg get() = ThemeState.palette.bg
    val Surface get() = ThemeState.palette.surface
    val Card get() = ThemeState.palette.card
    val Control get() = ThemeState.palette.control
    val Text get() = ThemeState.palette.text
    val TextSecondary get() = ThemeState.palette.textSecondary
    val Accent get() = ThemeState.palette.accent
    val OnAccent get() = ThemeState.palette.onAccent
    val AccentText get() = ThemeState.palette.accentText
    val Positive get() = ThemeState.palette.positive
    val Danger get() = ThemeState.palette.danger
    val Warm get() = ThemeState.palette.warm
    val Divider get() = ThemeState.palette.divider
    val Scrim get() = ThemeState.palette.scrim
    val HeroTop get() = ThemeState.palette.heroTop
    val Glass get() = ThemeState.palette.glass
    val GlassOpaque get() = ThemeState.palette.glassOpaque
    val GlassBorder get() = ThemeState.palette.glassBorder
    val isDark get() = ThemeState.palette.dark
    /**
     * Capa translúcida de hojas y desplegables, teñida con el acento elegido en Apariencia.
     * La proporción es baja (y menor con acentos muy claros u oscuros) para que texto, iconos
     * y selección sigan distinguiéndose; se recalcula al cambiar el acento o el modo.
     */
    val AccentGlass: androidx.compose.ui.graphics.Color get() = AccentMaterial.glass()
    /** Hojas con formularios: base más densa. */
    val AccentGlassDense: androidx.compose.ui.graphics.Color get() = AccentMaterial.glass(dense = true)
    val AccentGlassOpaque: androidx.compose.ui.graphics.Color get() = AccentMaterial.glassOpaque()
}

object Dim {
    val screenH = 20.dp
    val section = 28.dp
    val cardPad = 18.dp
    val related = 10.dp
    val cardRadius = 22.dp
    val sheetRadius = 30.dp
    val buttonH = 54.dp
    val quickAction = 52.dp
    val touch = 48.dp
    val icon = 24.dp
    val rowIcon = 40.dp
    /** Cápsula inferior: alto, margen lateral y separación sobre la barra del sistema. */
    val capsuleH = 64.dp
    val capsuleSide = 18.dp
    val capsuleGap = 10.dp
    /** Espacio reservado al final de cada lista para leer y pulsar el último elemento. */
    val listEnd = capsuleH + capsuleGap + 28.dp
    /** Zona de desvanecido bajo la cabecera fija (24–40 dp). */
    val fadeZone = 32.dp
}

object Motion {
    const val press = 100
    const val pressScale = 0.98f
    /** Selección de pestaña, reflejo y lente comparten esta transición (200–280 ms). */
    const val tab = 240
    const val detail = 250
    const val sheet = 290
    /** Desplegables: respuesta a la presión, apertura y recogida. */
    const val menuOpen = 260
    const val menuClose = 190
    const val value = 400
}

val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

/** Interletraje −0,085 em reservado a titulares grandes. */
private val Tight = (-0.085).em
private val Snug = (-0.03).em

/** Estilos tipográficos (se recalculan con la paleta vigente). Cifras tabulares en temporizadores. */
object Type {
    val hero get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 52.sp, lineHeight = 56.sp, letterSpacing = Tight, color = TT.Text)
    val heroUnit get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 26.sp, letterSpacing = (-0.04).em, color = TT.Text)
    val screenTitle get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 36.sp, letterSpacing = Tight, color = TT.Text)
    val section get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 26.sp, letterSpacing = Snug, color = TT.Text)
    val cardTitle get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp, letterSpacing = (-0.01).em, color = TT.Text)
    val cardFigure get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 32.sp, letterSpacing = (-0.05).em, color = TT.Text, fontFeatureSettings = "tnum")
    val body get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 22.sp, color = TT.Text)
    val bodyMedium get() = body.copy(fontWeight = FontWeight.Medium)
    val button get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, letterSpacing = (-0.01).em)
    val secondary get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 19.sp, color = TT.TextSecondary)
    val label get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 17.sp, letterSpacing = 0.01.em, color = TT.TextSecondary)
    val countdown get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 72.sp, lineHeight = 76.sp, letterSpacing = (-0.06).em, color = TT.Text, fontFeatureSettings = "tnum")
    /** Temporizador principal: cifras grandes de ancho estable. */
    val timer get() = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 76.sp, lineHeight = 80.sp, letterSpacing = (-0.05).em, color = TT.Text, fontFeatureSettings = "tnum, lnum")
    val tabular get() = body.copy(fontFeatureSettings = "tnum")
}
