package app.minibunker.glass

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Geometría de la lente de fuckstudy, sin Android, para poder probarla en la JVM.
 *
 * Es la misma cuenta que hace el sombreador AGSL de [app.minibunker.ui.frost.LensShader] (Android 13+)
 * y la que aproximan por bandas los equipos con Android 8–12:
 *
 *  - d = distancia con signo al canto de un rectángulo redondeado (negativa dentro).
 *  - t = 1 + d / bezel, acotado a 0..1: 0 en el interior, 1 en el canto.
 *  - La muestra del fondo se toma en p − n · disp · t², con n la normal hacia fuera. Cerca del centro la
 *    imagen queda a escala natural; al acercarse a la curva se desplaza perpendicularmente al canto y se
 *    amplía localmente. Fuera de la silueta no se dibuja nada (la escena conserva su posición exacta).
 *
 * Para que la imagen no se pliegue, la correspondencia debe ser monótona: d(muestra)/d(p) = 1 − 2·disp·t/bezel > 0,
 * es decir bezel > 2·disp. [Spec] lo garantiza.
 */
object LensMath {

    /** Radios de las esquinas en píxeles: arriba-izquierda, arriba-derecha, abajo-derecha, abajo-izquierda. */
    data class Radii(val tl: Float, val tr: Float, val br: Float, val bl: Float) {
        fun inset(by: Float) = Radii(max(0f, tl - by), max(0f, tr - by), max(0f, br - by), max(0f, bl - by))
        companion object { fun all(r: Float) = Radii(r, r, r, r) }
    }

    /** [bezel]: anchura de la franja curva; [disp]: desplazamiento máximo en el canto (px). */
    data class Spec(val bezel: Float, val disp: Float) {
        /** Desplazamiento efectivo: nunca más de un 45 % de la franja (sin pliegues). */
        val safeDisp: Float get() = min(disp, bezel * 0.45f)
    }

    /** Distancia con signo a un rectángulo redondeado centrado en el origen de semiejes (bx, by). */
    fun sdRoundRect(px: Float, py: Float, bx: Float, by: Float, r: Radii): Float {
        val rr = if (px > 0f) (if (py > 0f) r.br else r.tr) else (if (py > 0f) r.bl else r.tl)
        val rc = min(rr, min(bx, by))
        val qx = abs(px) - bx + rc
        val qy = abs(py) - by + rc
        val ox = max(qx, 0f); val oy = max(qy, 0f)
        return sqrt(ox * ox + oy * oy) + min(max(qx, qy), 0f) - rc
    }

    /** Resultado del muestreo en un punto local (x, y) de una pieza de w × h. */
    data class Sample(val inside: Boolean, val sx: Float, val sy: Float, val t: Float, val nx: Float, val ny: Float)

    fun sample(x: Float, y: Float, w: Float, h: Float, r: Radii, spec: Spec): Sample {
        val bx = w / 2f; val by = h / 2f
        val px = x - bx; val py = y - by
        val d = sdRoundRect(px, py, bx, by, r)
        if (d > 0f) return Sample(false, x, y, 0f, 0f, 0f)
        val e = 1f
        var gx = sdRoundRect(px + e, py, bx, by, r) - sdRoundRect(px - e, py, bx, by, r)
        var gy = sdRoundRect(px, py + e, bx, by, r) - sdRoundRect(px, py - e, bx, by, r)
        val gl = sqrt(gx * gx + gy * gy)
        if (gl > 1e-4f) { gx /= gl; gy /= gl } else { gx = 0f; gy = 0f }
        val t = (1f + d / spec.bezel).coerceIn(0f, 1f)
        val k = t * t
        val sx = (x - gx * spec.safeDisp * k).coerceIn(0.5f, w - 0.5f)
        val sy = (y - gy * spec.safeDisp * k).coerceIn(0.5f, h - 0.5f)
        return Sample(true, sx, sy, t, gx, gy)
    }

    /**
     * Aproximación por bandas para Android 8–12: [n] franjas concéntricas desde el canto hacia dentro;
     * en cada una la escena se dibuja escalada alrededor del centro para producir, en mitad de la franja,
     * el mismo desplazamiento que la lente continua. Devuelve (inicio de la franja, fin, escalaX, escalaY).
     */
    data class Band(val outerInset: Float, val innerInset: Float, val scaleX: Float, val scaleY: Float)

    fun bands(w: Float, h: Float, spec: Spec, n: Int = 4): List<Band> {
        val bez = min(spec.bezel, min(w, h) / 2f)
        if (bez < 2f) return emptyList()
        return (0 until n).map { i ->
            val o = bez * i / n
            val inn = bez * (i + 1) / n
            val tMid = 1f - (i + 0.5f) / n
            val off = spec.safeDisp * tMid * tMid
            val ex = w / 2f - (o + inn) / 2f
            val ey = h / 2f - (o + inn) / 2f
            Band(o, inn, if (ex > off + 1f) ex / (ex - off) else 1f, if (ey > off + 1f) ey / (ey - off) else 1f)
        }
    }
}
