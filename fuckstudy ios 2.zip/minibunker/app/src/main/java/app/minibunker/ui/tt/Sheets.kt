package app.minibunker.ui.tt

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.thinktwice.core.*
import app.thinktwice.data.Store
import app.thinktwice.system.Perms
import app.minibunker.ui.Dest
import app.minibunker.ui.LocalNav
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.*
import app.minibunker.ui.theme.*
import java.time.LocalDate

private val quickDurations = listOf(15 to "15 min", 30 to "30 min", 60 to "1 h", 120 to "2 h")

@Composable
fun BlockSheet(state: AppState, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val haptic = rememberHaptic()
    val first = state.templates.firstOrNull()
    var templateId by rememberSaveable { mutableStateOf(first?.id) }
    var name by rememberSaveable { mutableStateOf(first?.name ?: "Concentración") }
    var apps by rememberSaveable { mutableStateOf(first?.packages?.toList() ?: emptyList()) }
    var minutes by rememberSaveable { mutableIntStateOf(first?.durationMin ?: 30) }
    var customOpen by rememberSaveable { mutableStateOf(first != null && first.durationMin !in quickDurations.map { it.first }) }
    var customH by rememberSaveable { mutableStateOf((minutes / 60).toString()) }
    var customM by rememberSaveable { mutableStateOf((minutes % 60).toString()) }
    var picking by remember { mutableStateOf(false) }
    val guardOn = remember { Perms.isGuardEnabled(ctx) }

    val customMinutes = (customH.toIntOrNull() ?: 0) * 60 + (customM.toIntOrNull() ?: 0)
    val effective = if (customOpen) customMinutes else minutes
    val durationError = if (customOpen && customMinutes !in 1..24 * 60) "Elige entre 1 minuto y 24 horas." else null

    FrostSheet(
        onDismiss, "Nuevo bloqueo",
        primary = "Iniciar bloqueo", primaryEnabled = apps.isNotEmpty() && durationError == null && name.isNotBlank(),
        onPrimary = {
            val now = System.currentTimeMillis()
            val s = BlockSession(Store.newId(), name.trim(), apps.toSet(), now, now + effective * 60_000L)
            Store.update { it.copy(sessions = it.sessions + s) }
            haptic(); nav.show("Bloqueo iniciado"); onDismiss()
        },
    ) {
        Text("Plantillas", style = Type.label.copy(color = TT.Text))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            state.templates.forEach { t ->
                val sel = t.id == templateId
                Column(
                    Modifier.width(132.dp).clip(RoundedCornerShape(18.dp)).background(materialSurface())
                        .then(if (sel) Modifier.border(2.dp, TT.Accent, RoundedCornerShape(18.dp)) else Modifier)
                        .pressable {
                            templateId = t.id; name = t.name; apps = t.packages.toList(); minutes = t.durationMin
                            customOpen = t.durationMin !in quickDurations.map { it.first }
                            customH = (t.durationMin / 60).toString(); customM = (t.durationMin % 60).toString()
                        }
                        .padding(14.dp),
                ) {
                    RowIcon(routineIcon(t.icon))
                    Spacer(Modifier.height(10.dp))
                    Text(t.name, style = Type.bodyMedium, maxLines = 1)
                    Text("${Fmt.duration(t.durationMin * 60_000L)} · ${appsSummary(t.packages.size)}", style = Type.label, maxLines = 2)
                }
            }
        }
        Text("Editar plantillas", style = Type.bodyMedium.copy(color = TT.Accent),
            modifier = Modifier.padding(vertical = 12.dp).pressable { onDismiss(); nav.push(Dest.Templates) })

        LabeledField("Nombre", name, { name = it.take(40) }, error = if (name.isBlank()) "Escribe un nombre." else null)
        Spacer(Modifier.height(16.dp))
        ListGroup {
            ListRow("Aplicaciones", if (apps.isEmpty()) "Elige al menos una" else appsSummary(apps.size),
                leading = { RowIcon(Icons.Rounded.Apps) }, chevron = true, onClick = { picking = true })
        }
        if (apps.isNotEmpty()) { Spacer(Modifier.height(10.dp)); AppStack(apps, 8) }
        Spacer(Modifier.height(20.dp))
        Text("Duración", style = Type.label.copy(color = TT.Text))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            quickDurations.forEach { (m, l) -> Chip(l, !customOpen && minutes == m, { minutes = m; customOpen = false }) }
            Chip("Personalizada", customOpen, { customOpen = true })
        }
        if (customOpen) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LabeledField("Horas", customH, { customH = it.filter(Char::isDigit).take(2) }, Modifier.weight(1f), numeric = true)
                LabeledField("Minutos", customM, { customM = it.filter(Char::isDigit).take(2) }, Modifier.weight(1f), numeric = true)
            }
            durationError?.let { Text(it, style = Type.label.copy(color = TT.Danger), modifier = Modifier.padding(top = 6.dp)) }
        }
        Spacer(Modifier.height(16.dp))
        if (!guardOn) Banner(BannerKind.Error, "Protección no operativa",
            "La sesión se guardará, pero thinktwice no podrá mostrar el bloqueo hasta activar su servicio en Accesibilidad.")
        else Text("Podrás terminarla antes con la salida de emergencia. Llamadas, Ajustes y apps esenciales nunca se bloquean.", style = Type.label)
    }

    if (picking) AppPickerSheet("Apps a bloquear", apps.toSet(), { picking = false }) { apps = it.toList(); picking = false }
}

@Composable
fun PauseSheet(state: AppState, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val nav = LocalNav.current
    val haptic = rememberHaptic()
    var apps by remember { mutableStateOf(state.pausedApps) }
    var wait by remember { mutableIntStateOf(state.settings.waitSeconds) }
    var allowed by remember { mutableIntStateOf(state.settings.allowedMinutes) }
    var picking by remember { mutableStateOf(false) }
    val guardOn = remember { Perms.isGuardEnabled(ctx) }

    FrostSheet(onDismiss, "Pausa consciente", primary = "Guardar", onPrimary = {
        Store.update { it.copy(pausedApps = apps, settings = it.settings.copy(waitSeconds = wait, allowedMinutes = allowed)) }
        haptic(); nav.show(if (apps.isEmpty()) "Pausas desactivadas" else "Pausas guardadas"); onDismiss()
    }) {
        Text("Antes de abrir estas apps verás una cuenta atrás y podrás decidir si continuar.", style = Type.secondary)
        Spacer(Modifier.height(16.dp))
        ListGroup {
            ListRow("Apps con pausa", appsSummary(apps.size), leading = { RowIcon(Icons.Rounded.HourglassTop) }, chevron = true, onClick = { picking = true })
        }
        Spacer(Modifier.height(20.dp))
        Text("Espera", style = Type.label.copy(color = TT.Text)); Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 10, 15, 30, 60).forEach { Chip("$it s", wait == it, { wait = it }) }
        }
        Spacer(Modifier.height(20.dp))
        Text("Uso permitido después", style = Type.label.copy(color = TT.Text)); Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1, 5, 10, 15, 30).forEach { Chip("$it min", allowed == it, { allowed = it }) }
        }
        Spacer(Modifier.height(12.dp))
        Text("Si sales y vuelves dentro de ese intervalo no se repite la pausa. Al terminar, si sigues en la app, la pausa vuelve a aparecer.", style = Type.label)
        if (!guardOn) { Spacer(Modifier.height(16.dp)); Banner(BannerKind.Error, "Protección no operativa", "Activa el servicio de thinktwice en Accesibilidad para que la pausa aparezca.") }
    }
    if (picking) AppPickerSheet("Apps con pausa", apps, { picking = false }) { apps = it; picking = false }
}

@Composable
fun NewChallengeSheet(state: AppState, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val haptic = rememberHaptic()
    var kind by rememberSaveable { mutableStateOf(ChallengeKind.DAILY_SESSION) }
    var days by rememberSaveable { mutableIntStateOf(7) }
    var routineId by rememberSaveable { mutableStateOf(state.routines.firstOrNull()?.id) }
    var goal by rememberSaveable { mutableStateOf("60") }
    var reminder by rememberSaveable { mutableStateOf(false) }
    val goalErr = if (kind == ChallengeKind.USAGE_GOAL && (goal.toIntOrNull() ?: -1) !in 0..1440) "Introduce minutos entre 0 y 1440." else null
    val routineErr = if (kind == ChallengeKind.ROUTINE && routineId == null) "Primero crea una rutina." else null

    FrostSheet(onDismiss, "Nuevo reto", primary = "Empezar hoy", primaryEnabled = goalErr == null && routineErr == null, onPrimary = {
        val c = Challenge(Store.newId(), kind, days, LocalDate.now().toEpochDay(),
            routineId = if (kind == ChallengeKind.ROUTINE) routineId else null,
            goalMinutes = if (kind == ChallengeKind.USAGE_GOAL) goal.toInt() else null, reminder = reminder)
        Store.update { it.copy(challenges = it.challenges + c) }
        haptic(); nav.show("Reto creado"); onDismiss()
    }) {
        Text("Un reto es un periodo de seguimiento de un compromiso, no un bloqueo del móvil.", style = Type.secondary)
        Spacer(Modifier.height(16.dp))
        Text("Regla", style = Type.label.copy(color = TT.Text)); Spacer(Modifier.height(8.dp))
        Segmented(listOf("Sesión diaria", "Rutina", "Objetivo de uso"),
            listOf(ChallengeKind.DAILY_SESSION, ChallengeKind.ROUTINE, ChallengeKind.USAGE_GOAL).indexOf(kind),
            { kind = listOf(ChallengeKind.DAILY_SESSION, ChallengeKind.ROUTINE, ChallengeKind.USAGE_GOAL)[it] })
        Spacer(Modifier.height(16.dp))
        when (kind) {
            ChallengeKind.ROUTINE -> {
                if (state.routines.isEmpty()) Text("No tienes rutinas todavía.", style = Type.label.copy(color = TT.Danger))
                else Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.routines.forEach { r -> Chip(r.name, routineId == r.id, { routineId = r.id }) }
                }
            }
            ChallengeKind.USAGE_GOAL -> LabeledField("Máximo diario en apps distractoras (min)", goal, { goal = it.filter(Char::isDigit).take(4) },
                numeric = true, error = goalErr, help = "Se mide con el acceso a datos de uso y tu clasificación de apps.")
            ChallengeKind.DAILY_SESSION -> Text("Cuenta un día como cumplido si completas una sesión de bloqueo sin terminarla antes.", style = Type.label)
        }
        Spacer(Modifier.height(20.dp))
        Text("Duración", style = Type.label.copy(color = TT.Text)); Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1 to "24 h", 2 to "48 h", 7 to "7 días", 21 to "21 días", 30 to "30 días").forEach { (d, l) -> Chip(l, days == d, { days = d }) }
        }
        Spacer(Modifier.height(16.dp))
        ListGroup {
            ListRow("Recordatorio diario", "Notificación local a las ${state.settings.reminderHour}:00", trailingSwitch = reminder, onSwitch = { reminder = it }, switchLabel = "Recordatorio diario")
        }
    }
}
