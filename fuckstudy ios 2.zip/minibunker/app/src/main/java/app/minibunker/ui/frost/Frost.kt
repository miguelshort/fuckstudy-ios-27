package app.minibunker.ui.frost

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.Snapshot
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import app.minibunker.ui.components.PillButton
import app.minibunker.ui.components.ButtonTone
import app.minibunker.ui.components.pressable
import app.minibunker.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/* ═════════════════════════ Fondo muestreado ═════════════════════════
 * La pantalla se graba en una capa gráfica (GraphicsLayer) que se dibuja normalmente y que,
 * además, las superficies translúcidas vuelven a dibujar desenfocada y recortada a su forma.
 * Orden de composición: 1) pantalla de fondo, 2) desenfoque recortado, 3) contenido nítido encima.
 */
class Backdrop(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
    /** Se incrementa cada vez que el fondo se vuelve a dibujar, para refrescar las superficies. */
    var version by mutableIntStateOf(0)
}

val LocalBackdrop = staticCompositionLocalOf<Backdrop?> { null }

@Composable
fun rememberBackdrop(): Backdrop { val l = rememberGraphicsLayer(); return remember(l) { Backdrop(l) } }

/** Graba el contenido en la capa del fondo y lo dibuja. */
fun Modifier.backdropSource(b: Backdrop): Modifier = this
    .onGloballyPositioned { b.origin = it.positionInRoot() }
    .drawWithContent {
        b.layer.record { this@drawWithContent.drawContent() }
        drawLayer(b.layer)
        // Sin observar la lectura: si no, el propio fondo se invalidaría a sí mismo en bucle.
        Snapshot.withoutReadObservation { b.version++ }
    }

/**
 * Superficie de vidrio compartida: lente con refracción real de la escena posterior (ver Lens.kt),
 * sin desenfoque. [bezel] y [disp]: anchura de la curva y desplazamiento máximo en el canto. En paneles
 * grandes el espesor se concentra cerca de la orilla para poder leer todo el interior.
 * Con contraste elevado o sin escena, superficie opaca del mismo tono ([opaqueTint]).
 */
@Composable
fun Modifier.frosted(
    shape: Shape, tint: Color = TT.AccentGlass, opaqueTint: Color = TT.AccentGlassOpaque,
    bezel: Dp = 18.dp, disp: Dp = 3.dp, edgeFade: Float = 0.7f,
): Modifier {
    val b = LocalBackdrop.current
    val lens = rememberLens()
    var pos by remember { mutableStateOf(Offset.Zero) }
    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .drawBehind {
            val look = LensLook(tint, edgeFade, AccentMaterial.lensLight(), bezel.toPx(), disp.toPx())
            lens.draw(this, b, pos, Rect(Offset.Zero, size), radiiOf(shape, size), look, opaqueTint)
        }
}

/* ═════════════════════════ Capa superpuesta (portal) ═════════════════════════
 * Hojas y menús se dibujan por encima de la pantalla (y fuera de la capa del fondo) aunque
 * se declaren dentro de cada pantalla, que conserva su estado.
 */
class OverlayEntry(val key: Any, val modal: Boolean) {
    var content: State<@Composable () -> Unit>? = null
    var visible by mutableStateOf(true)
}

class OverlayHost {
    val entries = mutableStateListOf<OverlayEntry>()
    val hasModal get() = entries.any { it.modal }
    fun remove(e: OverlayEntry) { entries.remove(e) }
}

val LocalOverlay = staticCompositionLocalOf { OverlayHost() }

/** Dibuja las entradas modales (hojas) o las no modales (desplegables) de la capa superpuesta. */
@Composable
fun OverlayLayer(host: OverlayHost, modal: Boolean) {
    host.entries.forEachIndexed { i, e ->
        if (e.modal == modal) key(e.key) { Box(Modifier.zIndex(i.toFloat())) { e.content?.value?.invoke() } }
    }
}

@Composable
private fun rememberOverlay(modal: Boolean, content: @Composable (OverlayEntry) -> Unit): OverlayEntry {
    val host = LocalOverlay.current
    val entry = remember { OverlayEntry(Any(), modal) }
    val latest = rememberUpdatedState<@Composable () -> Unit> { content(entry) }
    DisposableEffect(entry) {
        entry.content = latest
        entry.visible = true
        if (entry !in host.entries) host.entries.add(entry)
        onDispose { entry.visible = false } // la propia hoja se retira al terminar su animación de salida
    }
    return entry
}

/* ═════════════════════════ Hoja inferior ═════════════════════════ */

/**
 * Hoja translúcida para formularios: tirador, título, campos desplazables y acción principal
 * accesible con el teclado abierto. Se abre al declararla y se cierra al dejar de declararla.
 */
@Composable
fun FrostSheet(
    onDismiss: () -> Unit,
    title: String,
    primary: String? = null,
    primaryEnabled: Boolean = true,
    onPrimary: (() -> Unit)? = null,
    primaryTone: ButtonTone = ButtonTone.Light,
    returnFocus: FocusRequester? = null,
    footer: (@Composable ColumnScope.() -> Unit)? = null,
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    val dismiss by rememberUpdatedState(onDismiss)
    rememberOverlay(modal = true) { entry ->
        SheetFrame(entry, title, { dismiss() }, primary, primaryEnabled, onPrimary, primaryTone, returnFocus, footer, scrollable, content)
    }
}

@Composable
private fun SheetFrame(
    entry: OverlayEntry, title: String, onDismiss: () -> Unit,
    primary: String?, primaryEnabled: Boolean, onPrimary: (() -> Unit)?, primaryTone: ButtonTone,
    returnFocus: FocusRequester?, footer: (@Composable ColumnScope.() -> Unit)?, scrollable: Boolean,
    content: @Composable ColumnScope.() -> Unit,
) {
    val host = LocalOverlay.current
    val reduce = LocalReduceMotion.current
    val progress = remember { Animatable(0f) }
    val drag = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val isTop = host.entries.lastOrNull { it.modal && it.visible } === entry

    LaunchedEffect(entry.visible) {
        if (entry.visible) {
            if (reduce) progress.snapTo(1f) else progress.animateTo(1f, tween(Motion.sheet, easing = FastOutSlowInEasing))
        } else {
            if (reduce) progress.snapTo(0f) else progress.animateTo(0f, tween(Motion.sheet, easing = FastOutSlowInEasing))
            host.remove(entry)
            // Devuelve el foco al control que abrió la hoja.
            delay(16); runCatching { returnFocus?.requestFocus() }
        }
    }
    BackHandler(enabled = entry.visible && isTop) { onDismiss() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val maxH = maxHeight * 0.92f
        // Exterior oscurecido: aparece a la vez que sube la hoja. Tocarlo la cierra.
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { alpha = progress.value }
                .background(TT.Scrim)
                .then(if (entry.visible) Modifier.clickable(remember { MutableInteractionSource() }, null) { onDismiss() } else Modifier)
                .clearAndSetSemantics { },
        )
        var sheetH by remember { mutableIntStateOf(0) }
        val shape = RoundedCornerShape(topStart = Dim.sheetRadius, topEnd = Dim.sheetRadius)
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = maxH)
                .onGloballyPositioned { sheetH = it.size.height }
                .offset { IntOffset(0, ((1f - progress.value) * (sheetH.takeIf { it > 0 } ?: with(density) { maxH.roundToPx() })).roundToInt() + drag.value.roundToInt()) }
                .frosted(shape, tint = TT.AccentGlassDense, opaqueTint = TT.AccentGlassOpaque, bezel = 22.dp, disp = 4.dp)
                .clip(shape)
                .clickable(remember { MutableInteractionSource() }, null) {} // no deja pasar toques al exterior
                .semantics { paneTitle = title; isTraversalGroup = true }
                .imePadding(),
        ) {
            // Tirador: arrastrar hacia abajo cierra la hoja.
            Box(
                Modifier.fillMaxWidth().height(28.dp)
                    .draggable(
                        rememberDraggableState { d -> scope.launch { drag.snapTo((drag.value + d).coerceAtLeast(0f)) } },
                        Orientation.Vertical,
                        onDragStopped = { v ->
                            if (drag.value > sheetH * 0.28f || v > 1800f) onDismiss()
                            scope.launch { drag.animateTo(0f, tween(180)) }
                        },
                    ),
                contentAlignment = Alignment.Center,
            ) { Box(Modifier.size(36.dp, 4.dp).clip(CircleShape).background(TT.TextSecondary.copy(alpha = 0.45f))) }
            Row(Modifier.fillMaxWidth().padding(start = Dim.screenH, end = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = Type.section, modifier = Modifier.weight(1f).semantics { heading() })
                Box(
                    Modifier.size(Dim.touch).pressable { onDismiss() }.semantics { contentDescription = "Cerrar"; role = Role.Button },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(TT.Control), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Close, null, tint = TT.Text, modifier = Modifier.size(18.dp))
                    }
                }
            }
            CompositionLocalProvider(LocalMaterialDepth provides 1) {
                Column(
                    Modifier.weight(1f, fill = false)
                        .then(if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                        .padding(horizontal = Dim.screenH),
                    content = content,
                )
            }
            if (footer != null) Column(Modifier.padding(horizontal = Dim.screenH), content = footer)
            if (primary != null && onPrimary != null) {
                PillButton(primary, onPrimary, enabled = primaryEnabled, tone = primaryTone,
                    modifier = Modifier.fillMaxWidth().padding(start = Dim.screenH, end = Dim.screenH, top = 12.dp, bottom = 14.dp).navigationBarsPadding())
            } else Spacer(Modifier.navigationBarsPadding().height(16.dp))
        }
    }
}

/* ═════════════════════════ Menú anclado ═════════════════════════ */

data class MenuOption<T>(val value: T, val label: String, val detail: String? = null)

/**
 * Lista anclada al control que la abre: el propio botón se convierte en el menú.
 * [anchor]: límites del control en la raíz (ver Modifier.anchorBounds). [origin]: punto de contacto en la raíz
 * (null si se abrió con teclado o TalkBack: se usa el centro del control).
 */
@Composable
fun <T> FrostMenu(anchor: Rect, options: List<MenuOption<T>>, selected: T?, onDismiss: () -> Unit, origin: Offset? = null, onSelect: (T) -> Unit) {
    val dismiss by rememberUpdatedState(onDismiss)
    val select by rememberUpdatedState(onSelect)
    rememberOverlay(modal = false) { entry -> MenuFrame(entry, anchor, origin, options, selected, { dismiss() }, { select(it) }) }
}

/** Geometría final del menú: mide el espacio real y elige la dirección que deja leer más opciones. */
private data class MenuGeom(val rect: Rect, val below: Boolean)

@Composable
private fun <T> MenuFrame(
    entry: OverlayEntry, anchor: Rect, origin: Offset?, options: List<MenuOption<T>>, selected: T?,
    onDismiss: () -> Unit, onSelect: (T) -> Unit,
) {
    val host = LocalOverlay.current
    val reduce = LocalReduceMotion.current
    val scene = LocalBackdrop.current
    val lens = rememberLens()
    // Progreso único de la transformación campo → panel (0 = el campo, 1 = el menú asentado).
    val p = remember { Animatable(if (reduce) 1f else 0f) }
    LaunchedEffect(entry.visible) {
        if (entry.visible) {
            // Salida rápida y llegada amortiguada, con un único asentamiento.
            if (reduce) p.snapTo(1f) else p.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 520f))
        } else {
            // Recoge siguiendo el trayecto inverso; si se interrumpe, parte de su geometría y velocidad actuales.
            if (reduce) p.snapTo(0f) else p.animateTo(0f, tween(Motion.menuClose, easing = FastOutLinearInEasing))
            host.remove(entry)
        }
    }
    BackHandler(enabled = entry.visible) { onDismiss() }
    val density = LocalDensity.current
    val imeBottom = WindowInsets.ime.getBottom(density).toFloat()
    val statusTop = WindowInsets.statusBars.getTop(density).toFloat()
    val navBottom = WindowInsets.navigationBars.getBottom(density).toFloat()
    var rootPos by remember { mutableStateOf(Offset.Zero) }
    BoxWithConstraints(Modifier.fillMaxSize().onGloballyPositioned { rootPos = it.positionInRoot() }) {
        val px = { d: Dp -> with(density) { d.toPx() } }
        val screenH = px(maxHeight); val screenW = px(maxWidth)
        val itemH = px(52.dp); val vpad = px(8.dp); val gap = px(6.dp); val margin = px(12.dp)
        val geom = remember(anchor, options.size, imeBottom, statusTop, navBottom, screenH, screenW) {
            // Espacio real: sin barra de estado, sin teclado ni navegación del sistema.
            val topLimit = statusTop + margin
            val bottomLimit = screenH - maxOf(imeBottom, navBottom) - margin
            val spaceBelow = bottomLimit - (anchor.bottom + gap)
            val spaceAbove = (anchor.top - gap) - topLimit
            // Unas cuatro filas visibles (la media fila siguiente indica que hay más).
            val ideal = (options.size * itemH + 2 * vpad).coerceAtMost(4.5f * itemH + 2 * vpad)
            val below = spaceBelow >= ideal || spaceBelow >= spaceAbove
            val listH = minOf(ideal, maxOf(if (below) spaceBelow else spaceAbove, 2.5f * itemH)).coerceAtLeast(itemH + 2 * vpad)
            val w = maxOf(anchor.width, px(220.dp)).coerceAtMost(screenW - px(32.dp))
            val x = anchor.left.coerceIn(px(16.dp), screenW - w - px(16.dp))
            val y = (if (below) anchor.bottom + gap else anchor.top - gap - listH).coerceIn(topLimit, (bottomLimit - listH).coerceAtLeast(topLimit))
            MenuGeom(Rect(x, y, x + w, y + listH), below)
        }
        val fieldR = px(16.dp); val menuR = px(Dim.cardRadius)
        val touch = origin ?: anchor.center
        val pv = p.value
        // Silueta interpolada (rectángulo, radios, espesor y sombra con el mismo progreso). En el primer
        // tramo el cristal cede levemente bajo el dedo.
        val give = (1f - pv / 0.15f).coerceIn(0f, 1f) * px(2.dp)
        val cur = lerpRect(anchor, geom.rect, pv.coerceIn(0f, 1.08f)).deflate(give)
        val radius = androidx.compose.ui.util.lerp(fieldR, menuR, pv.coerceIn(0f, 1f))
        val radii = app.minibunker.glass.LensMath.Radii.all(radius)
        val press = (1f - pv / 0.35f).coerceIn(0f, 1f)
        // Toque fuera: recoge conservando el valor previo.
        Box(Modifier.fillMaxSize().then(if (entry.visible) Modifier.clickable(remember { MutableInteractionSource() }, null) { onDismiss() } else Modifier))
        // La pieza de vidrio: una sola, continua, desde el campo hasta el panel.
        Box(
            Modifier.fillMaxSize().drawBehind {
                val local = cur.translate(-rootPos.x, -rootPos.y)
                softShadow(local, radii, 0.22f * pv.coerceIn(0f, 1f))
                val look = LensLook(
                    tint = AccentMaterial.lensTint(AccentMaterial.Kind.MENU).let { it.copy(alpha = it.alpha * (0.55f + 0.45f * pv.coerceIn(0f, 1f))) },
                    edgeFade = 0.55f, light = AccentMaterial.lensLight(),
                    bezel = androidx.compose.ui.util.lerp(px(10.dp), px(16.dp), pv.coerceIn(0f, 1f)), disp = px(4.dp),
                    touch = touch - cur.topLeft, press = press,
                )
                lens.draw(this, scene, rootPos, local, radii, look, AccentMaterial.glassOpaque())
            },
        )
        // Opciones: maquetadas ya en su sitio final y a su tamaño de lectura; se revelan a medida que la
        // silueta tiene espacio para contenerlas.
        val shape = RoundedCornerShape(Dim.cardRadius)
        val selIndex = options.indexOfFirst { it.value == selected }.coerceAtLeast(0)
        // Al abrir, la selección actual queda a la vista dentro de la lista.
        val listState = rememberLazyListState(initialFirstVisibleItemIndex = (selIndex - 1).coerceAtLeast(0))
        val more by remember { derivedStateOf { listState.canScrollForward } }
        val g = geom.rect
        val contentAlpha = ((pv - 0.35f) / 0.4f).coerceIn(0f, 1f)
        Box(
            Modifier.offset { IntOffset((g.left - rootPos.x).roundToInt(), (g.top - rootPos.y).roundToInt()) }
                .size(with(density) { g.width.toDp() }, with(density) { g.height.toDp() })
                .graphicsLayer { alpha = contentAlpha }
                .drawWithContent {
                    val clip = cur.translate(-g.left, -g.top)
                    clipPath(roundRectPath(clip, radii)) { this@drawWithContent.drawContent() }
                }
                .clip(shape)
                .semantics { paneTitle = "Opciones" },
        ) {
            LazyColumn(state = listState, contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize(), userScrollEnabled = pv > 0.6f) {
                items(options.size) { i ->
                    val o = options[i]
                    val sel = o.value == selected
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 52.dp)
                            .pressable(enabled = entry.visible && pv > 0.6f, scaleDown = false, role = Role.RadioButton) { onSelect(o.value); onDismiss() }
                            .semantics { this.selected = sel; collectionItemInfo = CollectionItemInfo(i, 1, 0, 1) }
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(o.label, style = Type.bodyMedium.copy(color = if (sel) TT.AccentText else TT.Text), maxLines = 2)
                            if (o.detail != null) Text(o.detail, style = Type.label, maxLines = 1)
                        }
                        if (sel) Icon(Icons.Rounded.Check, null, tint = TT.AccentText, modifier = Modifier.size(20.dp))
                    }
                }
            }
            // Indicación visible de que hay más opciones debajo.
            if (more) Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(30.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, AccentMaterial.lensTint(AccentMaterial.Kind.MENU).copy(alpha = 0.9f)))),
                contentAlignment = Alignment.BottomCenter,
            ) { Icon(Icons.Rounded.KeyboardArrowDown, "Hay más opciones", tint = TT.TextSecondary, modifier = Modifier.size(20.dp)) }
        }
    }
}

private fun lerpRect(a: Rect, b: Rect, t: Float) = Rect(
    a.left + (b.left - a.left) * t, a.top + (b.top - a.top) * t, a.right + (b.right - a.right) * t, a.bottom + (b.bottom - a.bottom) * t,
)

/** Guarda los límites del elemento en la raíz (para anclar menús). */
fun Modifier.anchorBounds(onBounds: (Rect) -> Unit): Modifier = this.onGloballyPositioned { onBounds(it.boundsInRoot()) }

/* ═════════════════════════ Desvanecido bajo la cabecera ═════════════════════════ */

/**
 * Desvanece suavemente el contenido que sale por arriba en los primeros [zone] dp bajo la cabecera
 * fija. El título y los controles de la cabecera quedan fuera y siguen nítidos; el texto que aún se
 * lee (por debajo de la zona) no se toca. Solo se aplica cuando hay contenido desplazado.
 */
@Composable
fun Modifier.fadeTop(active: Boolean, zone: Dp = Dim.fadeZone): Modifier {
    val a by animateFloatAsState(if (active) 1f else 0f, ttTween(Motion.tab), label = "fade")
    return fadeTopBy({ a }, zone)
}

/**
 * Variante gradual: [amount] (0–1) sigue al desplazamiento real, así el desvanecido aparece solo a
 * medida que el contenido pasa por debajo de la cabecera fija y en reposo no atenúa nada.
 */
@Composable
fun Modifier.fadeTop(state: androidx.compose.foundation.lazy.LazyListState, zone: Dp = Dim.fadeZone): Modifier {
    val zonePx = with(LocalDensity.current) { zone.toPx() }
    return fadeTopBy({
        if (state.firstVisibleItemIndex > 0) 1f else (state.firstVisibleItemScrollOffset / zonePx).coerceIn(0f, 1f)
    }, zone)
}

private fun Modifier.fadeTopBy(amount: () -> Float, zone: Dp): Modifier {
    return this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val a = amount()
            if (a > 0f) {
                val h = zone.toPx()
                drawRect(
                    Brush.verticalGradient(0f to Color.Black.copy(alpha = 1f - a), 1f to Color.Black, startY = 0f, endY = h),
                    size = androidx.compose.ui.geometry.Size(size.width, h), blendMode = BlendMode.DstIn,
                )
            }
        }
}
