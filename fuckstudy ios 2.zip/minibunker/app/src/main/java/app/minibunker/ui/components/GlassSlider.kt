package app.minibunker.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import app.minibunker.glass.LensMath
import app.minibunker.ui.frost.roundRectPath
import app.minibunker.ui.frost.softShadow
import app.minibunker.ui.theme.*

/**
 * Regulador continuo con tirador de vidrio: el tirador es una lente que amplía el tramo de pista que
 * tiene debajo (se distinguen el color de la pista y su extremo dentro del cristal) y recoge un reflejo
 * fino en parte del canto. Al tocarlo crece levemente. Con contraste elevado, tirador opaco.
 *
 * [onChange] se llama en vivo; [onChangeFinished] al soltar (para guardar).
 */
@Composable
fun GlassSlider(
    value: Float, onChange: (Float) -> Unit, onChangeFinished: () -> Unit,
    description: String, stateText: (Float) -> String, modifier: Modifier = Modifier,
) {
    var w by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (dragging) 1f else 0f, ttTween(Motion.press), label = "thumb")
    val v by rememberUpdatedState(value)
    val change by rememberUpdatedState(onChange)
    val finished by rememberUpdatedState(onChangeFinished)
    fun toValue(x: Float, pad: Float) = ((x - pad) / (w - 2 * pad)).coerceIn(0f, 1f)
    Box(
        modifier.fillMaxWidth().height(Dim.touch + 4.dp)
            .onSizeChanged { w = it.width.toFloat() }
            .semantics {
                contentDescription = description
                stateDescription = stateText(value)
                progressBarRangeInfo = ProgressBarRangeInfo(value, 0f..1f)
                setProgress { t -> change(t.coerceIn(0f, 1f)); finished(); true }
            }
            // Un solo gesto: tocar coloca el tirador y arrastrar lo mueve; al soltar se guarda.
            .pointerInput(Unit) {
                val pad = 22.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown()
                    dragging = true
                    change(toValue(down.position.x, pad)); down.consume()
                    while (true) {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!c.pressed) break
                        change(toValue(c.position.x, pad)); c.consume()
                    }
                    dragging = false
                    finished()
                }
            }
            .drawBehind {
                val pad = 22.dp.toPx()
                val cy = size.height / 2f
                val trackH = 6.dp.toPx()
                val x = pad + (size.width - 2 * pad) * v
                drawTrack(pad, cy, trackH, x)
                // Tirador: cápsula de vidrio.
                val tw = (38.dp.toPx()) * (1f + 0.18f * grow)
                val th = (24.dp.toPx()) * (1f + 0.18f * grow)
                val rect = Rect(Offset(x - tw / 2f, cy - th / 2f), Size(tw, th))
                val radii = LensMath.Radii.all(th / 2f)
                val path = roundRectPath(rect, radii)
                softShadow(rect, radii, if (TT.isDark) 0.30f else 0.14f, dy = 2.dp.toPx())
                if (ThemeState.solid) {
                    drawPath(path, TT.Text)
                } else clipPath(path) {
                    // Fondo de la lente: la base del tema, casi transparente.
                    drawRect(TT.Text.copy(alpha = if (TT.isDark) 0.10f else 0.06f), rect.topLeft, rect.size)
                    // Pista ampliada bajo el tirador (lente): misma pista, escalada alrededor del centro del tirador.
                    val mag = 1.45f + 0.25f * grow
                    scale(mag, mag, pivot = Offset(x, cy)) { drawTrack(pad, cy, trackH, x) }
                    // Reflejo fino en el canto superior y sombra suave abajo.
                    drawRect(Brush.verticalGradient(0f to Color.White.copy(alpha = AccentMaterial.lensLight() * 0.9f), 0.35f to Color.Transparent,
                        startY = rect.top, endY = rect.bottom), rect.topLeft, rect.size)
                    drawRect(Brush.verticalGradient(0.7f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.16f), startY = rect.top, endY = rect.bottom),
                        rect.topLeft, rect.size)
                }
            },
    )
}

private fun DrawScope.drawTrack(pad: Float, cy: Float, h: Float, x: Float) {
    val r = CornerRadius(h / 2f)
    drawRoundRect(TT.Control, Offset(pad, cy - h / 2f), Size(size.width - 2 * pad, h), r)
    drawRoundRect(TT.Accent, Offset(pad, cy - h / 2f), Size((x - pad).coerceAtLeast(h), h), r)
}

