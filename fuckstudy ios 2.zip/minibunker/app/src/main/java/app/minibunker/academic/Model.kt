package app.minibunker.academic

import app.minibunker.json.*

/**
 * Datos académicos con el MISMO formato que guarda la web de MIBUNKER en Firestore
 * (users/{uid}/data/{parte} → {"items": [...], "updated": ms}). Los nombres de campos,
 * valores por defecto y saneado reproducen las funciones mig* del index.html para que una
 * cuenta ya poblada se lea igual y la web siga entendiendo lo que escribe fuckstudy.
 *
 * Fechas "AAAA-MM-DD"; horas "HH:mm"; día de la semana del horario 0 = domingo … 6 = sábado (getDay de JS).
 */
enum class Part(val key: String) {
    EVENTS("events"), NOTES("notes"), GRADES("grades"), TIMETABLE("timetable"), SESSIONS("sessions"),
    PLANS("plans"), HABITS("habits"), SUBJECTS("subjects"), JORNADA("jornada");

    companion object { fun of(k: String) = entries.firstOrNull { it.key == k } }
}

/** Paleta de colores de MIBUNKER (asignaturas, hábitos, eventos). */
val PALETTE = listOf("#d4b06a", "#f3ede2", "#e07a6a", "#f0a35e", "#e9cf6b", "#7fbf8e", "#5fb8b0", "#6f9de0", "#9b87e0", "#e08fb8")

val CATS = listOf("personal" to "Personal", "trabajo" to "Trabajo", "estudio" to "Estudio", "ocio" to "Ocio", "importante" to "Importante")
val REPEATS = listOf("none" to "No se repite", "daily" to "Cada día", "weekly" to "Cada semana", "monthly" to "Cada mes", "yearly" to "Cada año")

fun okColor(c: String?): String = if (c != null && Regex("^#[0-9a-fA-F]{6}$").matches(c)) c.lowercase() else ""

private var idCounter = 0
/** Identificador con la misma forma que uid() de MIBUNKER (base 36 de la hora + aleatorio). */
fun newUid(): String {
    idCounter = (idCounter + 1) % 1296
    val rnd = (Math.random() * 36.0 * 36 * 36 * 36 * 36).toLong().toString(36).padStart(5, '0')
    return System.currentTimeMillis().toString(36) + rnd.take(3) + idCounter.toString(36).padStart(2, '0')
}

data class Event(
    val id: String, val date: String, val time: String = "", val end: String = "", val title: String = "",
    val note: String = "", val cat: String = "personal", val repeat: String = "none", val color: String = "",
) {
    fun toJson(): JObj = linkedMapOf("id" to id, "date" to date, "time" to time, "end" to end, "title" to title,
        "note" to note, "cat" to cat, "repeat" to repeat, "color" to color)
    companion object {
        fun from(o: JObj): Event? {
            val date = o.str("date"); if (date.isEmpty() || o.str("id") == "mwkhhkog3gqel") return null
            return Event(o.str("id").ifEmpty { newUid() }, date, o.str("time"), o.str("end"), o.str("title"), o.str("note"),
                o.str("cat").ifEmpty { "personal" }, o.str("repeat").ifEmpty { "none" }, okColor(o.strOrNull("color")))
        }
    }
}

data class NoteItem(val id: String, val t: String, val done: Boolean) {
    fun toJson(): JObj = linkedMapOf("id" to id, "t" to t, "done" to done)
}

data class Note(
    val id: String, val title: String = "", val body: String = "", val items: List<NoteItem> = emptyList(),
    val tone: String = "dark", val pinned: Boolean = false, val tags: List<String> = emptyList(), val updated: Long = System.currentTimeMillis(),
) {
    val isEmpty get() = title.isBlank() && body.isBlank() && items.isEmpty()
    fun toJson(): JObj = linkedMapOf("id" to id, "title" to title, "body" to body, "items" to items.map { it.toJson() },
        "tone" to tone, "tv" to 2, "pinned" to pinned, "tags" to tags, "updated" to updated)
    companion object {
        fun from(o: JObj): Note? {
            if (o.str("id") == "mwjlzsdi0fk71") return null
            val tv = o["tv"] != null && o["tv"] != false && o["tv"] != 0L
            val rawTone = o.str("tone")
            val tone = if (tv) rawTone.ifEmpty { "dark" } else when (rawTone) { "white" -> "dark"; "dark" -> "light"; "" -> "dark"; else -> rawTone }
            val n = Note(o.str("id").ifEmpty { newUid() }, o.str("title"), o.str("body"),
                o.objs("items").map { NoteItem(it.str("id").ifEmpty { newUid() }, it.str("t"), it.bool("done")) },
                tone, o.bool("pinned"), o.list("tags").mapNotNull { it as? String }, o.long("updated", System.currentTimeMillis()))
            return if (n.isEmpty) null else n
        }
    }
}

data class Grade(
    val id: String, val subject: String = "", val title: String = "", val date: String = "", val time: String = "",
    val score: Double? = null, val max: Double = 10.0, val weight: Double? = null, val note: String = "",
) {
    val pending get() = score == null
    /** Nota sobre 10 (g10 de MIBUNKER). */
    val g10: Double? get() = score?.let { (it / (if (max > 0) max else 10.0) * 10).coerceIn(0.0, 10.0) }
    fun toJson(): JObj = linkedMapOf("id" to id, "subject" to subject, "title" to title, "date" to date, "time" to time,
        "score" to score, "max" to max, "weight" to weight, "note" to note)
    companion object {
        fun from(o: JObj): Grade = Grade(o.str("id").ifEmpty { newUid() }, o.str("subject"), o.str("title"), o.str("date"), o.str("time"),
            o.num("score"), o.num("max")?.takeIf { it > 0 } ?: 10.0, o.num("weight"), o.str("note"))
    }
}

data class ClassEntry(
    val id: String, val day: Int, val start: String, val end: String, val slot: String = "", val subject: String,
    val teacher: String = "", val room: String = "", val color: String = "#d4b06a",
) {
    fun toJson(): JObj = linkedMapOf("id" to id, "day" to day, "start" to start, "end" to end, "slot" to slot,
        "subject" to subject, "teacher" to teacher, "room" to room, "color" to color)
    companion object {
        fun from(o: JObj): ClassEntry? {
            if (o.str("subject").isEmpty() || o.str("start").isEmpty() || o.str("end").isEmpty()) return null
            if (Regex("^tt[1-6]\\d$").matches(o.str("id"))) return null
            // Igual que la web (+c.day||1): un día ausente o 0 pasa a lunes.
            return ClassEntry(o.str("id").ifEmpty { newUid() }, o.int("day", 1).let { if (it == 0) 1 else it },
                o.str("start"), o.str("end"), o.str("slot"), o.str("subject"), o.str("teacher"), o.str("room"),
                okColor(o.strOrNull("color")).ifEmpty { "#d4b06a" })
        }
    }
}

data class StudySession(val id: String, val subject: String = "General", val date: String, val start: Long = 0, val mins: Int) {
    fun toJson(): JObj = linkedMapOf("id" to id, "subject" to subject, "date" to date, "start" to start, "mins" to mins)
    companion object {
        fun from(o: JObj): StudySession? {
            val mins = o.num("mins") ?: return null
            if (mins <= 0 || o.str("date").isEmpty()) return null
            return StudySession(o.str("id").ifEmpty { newUid() }, o.str("subject").ifEmpty { "General" }, o.str("date"), o.long("start"), Math.round(mins).toInt())
        }
    }
}

data class PlanItem(
    val id: String, val gid: String = "", val subject: String = "", val title: String, val date: String,
    val done: Boolean = false, val review: Boolean = false,
) {
    fun toJson(): JObj = linkedMapOf("id" to id, "gid" to gid, "subject" to subject, "title" to title, "date" to date, "done" to done, "review" to review)
    companion object {
        fun from(o: JObj): PlanItem? {
            if (o.str("title").isEmpty() || o.str("date").isEmpty()) return null
            return PlanItem(o.str("id").ifEmpty { newUid() }, o.str("gid"), o.str("subject"), o.str("title"), o.str("date"), o.bool("done"), o.bool("review"))
        }
    }
}

data class Habit(val id: String, val name: String, val color: String = "#d4b06a", val days: Map<String, Int> = emptyMap(), val created: Long = System.currentTimeMillis()) {
    fun done(date: String) = (days[date] ?: 0) != 0
    fun toJson(): JObj = linkedMapOf("id" to id, "name" to name, "color" to color, "days" to LinkedHashMap(days), "created" to created)
    companion object {
        fun from(o: JObj): Habit? {
            if (o.str("name").isEmpty()) return null
            val days = (o.objOrNull("days") ?: emptyMap()).entries.associate { it.key to ((it.value as? Number)?.toInt() ?: if (it.value == true) 1 else 0) }.filterValues { it != 0 }
            return Habit(o.str("id").ifEmpty { newUid() }, o.str("name"), okColor(o.strOrNull("color")).ifEmpty { "#d4b06a" }, days, o.long("created", System.currentTimeMillis()))
        }
    }
}

data class Subject(val id: String, val name: String, val teacher: String = "", val room: String = "", val color: String = "#6f9de0") {
    fun toJson(): JObj = linkedMapOf("id" to id, "name" to name, "teacher" to teacher, "room" to room, "color" to color)
    companion object {
        fun from(o: JObj): Subject? {
            if (o.str("name").isEmpty()) return null
            return Subject(o.str("id").ifEmpty { newUid() }, o.str("name"), o.str("teacher"), o.str("room"), okColor(o.strOrNull("color")).ifEmpty { "#6f9de0" })
        }
    }
}

/** Parámetros del generador de jornada (gen de MIBUNKER). */
data class JornadaGen(val start: String = "08:00", val dur: Int = 60, val n: Int = 6, val b1a: Int = 3, val b1: Int = 30, val b2a: Int = 0, val b2: Int = 0) {
    fun toJson(): JObj = linkedMapOf("start" to start, "dur" to dur, "n" to n, "b1a" to b1a, "b1" to b1, "b2a" to b2a, "b2" to b2)
    companion object {
        fun from(o: JObj?): JornadaGen? = o?.let {
            JornadaGen(it.str("start").ifEmpty { "08:00" }, it.int("dur", 60), it.int("n", 6), it.int("b1a", 3), it.int("b1", 30), it.int("b2a"), it.int("b2"))
        }
    }
}

sealed interface JornadaItem {
    val id: String
    fun toJson(): JObj
    data class Cfg(val days: List<Int> = listOf(1, 2, 3, 4, 5), val gen: JornadaGen? = null) : JornadaItem {
        override val id get() = "cfg"
        override fun toJson(): JObj = linkedMapOf("id" to "cfg", "kind" to "cfg", "days" to days, "gen" to gen?.toJson())
    }
    data class Slot(override val id: String, val isBreak: Boolean, val start: String, val end: String) : JornadaItem {
        override fun toJson(): JObj = linkedMapOf("id" to id, "kind" to if (isBreak) "break" else "class", "start" to start, "end" to end)
    }
    companion object {
        fun from(o: JObj): JornadaItem? {
            if (o.str("kind") == "cfg") return Cfg(o.list("days").mapNotNull { (it as? Number)?.toInt() }.ifEmpty { listOf(1, 2, 3, 4, 5) }, JornadaGen.from(o.objOrNull("gen")))
            if (o.str("start").isEmpty() || o.str("end").isEmpty()) return null
            return Slot(o.str("id").ifEmpty { newUid() }, o.str("kind") == "break", o.str("start"), o.str("end"))
        }
    }
}

/** Vista tipada e inmutable de todas las partes académicas. */
class Academic(val raw: Map<Part, List<JObj>>) {
    val events: List<Event> by lazy { raw[Part.EVENTS].orEmpty().mapNotNull(Event::from) }
    val notes: List<Note> by lazy { raw[Part.NOTES].orEmpty().mapNotNull(Note::from) }
    val grades: List<Grade> by lazy { raw[Part.GRADES].orEmpty().map(Grade::from) }
    val timetable: List<ClassEntry> by lazy { raw[Part.TIMETABLE].orEmpty().mapNotNull(ClassEntry::from) }
    val sessions: List<StudySession> by lazy { raw[Part.SESSIONS].orEmpty().mapNotNull(StudySession::from) }
    val plans: List<PlanItem> by lazy { raw[Part.PLANS].orEmpty().mapNotNull(PlanItem::from) }
    val habits: List<Habit> by lazy { raw[Part.HABITS].orEmpty().mapNotNull(Habit::from) }
    val subjects: List<Subject> by lazy { raw[Part.SUBJECTS].orEmpty().mapNotNull(Subject::from) }
    val jornada: List<JornadaItem> by lazy { raw[Part.JORNADA].orEmpty().mapNotNull(JornadaItem::from) }

    val isEmpty get() = raw.values.all { it.isEmpty() }

    companion object { val EMPTY = Academic(emptyMap()) }
}
