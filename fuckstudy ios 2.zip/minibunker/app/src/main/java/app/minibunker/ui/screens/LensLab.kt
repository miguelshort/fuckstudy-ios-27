package app.minibunker.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import app.minibunker.ui.components.DetailScaffold
import app.minibunker.ui.theme.*

/**
 * Prueba visual A («Lente en movimiento»): una cuadrícula fina, una banda azul y un icono que se desplazan
 * por debajo de la barra. Una misma línea debe ir recta antes de entrar, curvarse o ensancharse en el canto
 * (sin confundirse con la vecina) y recuperar su trayectoria al salir. El icono de la barra conserva su silueta.
 * Si las líneas solo pierden nitidez o solo cambian de color, la prueba falla.
 */
@Composable
fun LensLabScreen() {
    DetailScaffold("Prueba del cristal") {
        item {
            Text("Desplaza despacio y mira la barra inferior: cada línea se dobla al cruzar el canto y vuelve a su sitio al salir. " +
                "Las etiquetas de la barra no se deforman.", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
        }
        items(40) { i ->
            Box(Modifier.fillMaxWidth().height(72.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    val step = 12.dp.toPx()
                    val line = TT.TextSecondary.copy(alpha = 0.7f)
                    var x = 0f
                    while (x <= size.width) { drawLine(line, Offset(x, 0f), Offset(x, size.height), 1.dp.toPx()); x += step }
                    var y = 0f
                    while (y <= size.height) { drawLine(line, Offset(0f, y), Offset(size.width, y), 1.dp.toPx()); y += step }
                    // Banda azul diagonal continua entre filas.
                    val off = (i % 6) * size.height
                    drawLine(Color(0xFF2D6CFF), Offset(-off * 2f, size.height), Offset(size.width * 2f - off * 2f, -size.height * 0f), 10.dp.toPx())
                }
                if (i % 5 == 2) Icon(Icons.Rounded.Star, null, tint = TT.Text, modifier = Modifier.align(Alignment.Center).size(28.dp))
            }
        }
    }
}
