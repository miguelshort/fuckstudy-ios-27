package app.minibunker.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.minibunker.academic.AcadState
import app.minibunker.academic.AcademicRepo
import app.minibunker.study.StudyController
import app.minibunker.ui.components.pressable
import app.minibunker.ui.frost.*
import app.minibunker.ui.screens.*
import app.minibunker.ui.tt.*
import app.minibunker.ui.theme.*
import app.thinktwice.core.AppState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot

@Composable
fun AppRoot(tt: AppState, ac: AcadState) {
    val nav = remember { Nav() }
    // Restaura la pestaña tras recrear la actividad; la antigua «Notas» abre Hábitos.
    var savedTab by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { savedTab?.let { nav.tab = Tab.restore(it) } }
    LaunchedEffect(nav.tab) { savedTab = nav.tab.name }
    val overlay = remember { OverlayHost() }
    // Escena de la pantalla (la refractan la barra y las hojas) y escena completa con hojas y barra
    // (la refractan los desplegables, que así incluyen la hoja real desde la que se abren).
    val backdrop = rememberBackdrop()
    val sceneAll = rememberBackdrop()
    var resumeTick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> { resumeTick++; StudyController.tick(); AcademicRepo.startPolling() }
                Lifecycle.Event.ON_PAUSE -> AcademicRepo.stopPolling()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }

    CompositionLocalProvider(LocalNav provides nav, LocalOverlay provides overlay, LocalBackdrop provides backdrop, LocalResumeTick provides resumeTick) {
        val main = !ac.needsAuth && tt.settings.onboardingDone
        BackHandler(enabled = main && !overlay.hasModal && (nav.depth > 0 || nav.tab != Tab.HOY)) { nav.back() }
        Box(Modifier.fillMaxSize().background(TT.Bg)) {
            Box(Modifier.fillMaxSize().background(TT.Bg).backdropSource(sceneAll)) {
                // 1) Pantalla de fondo, grabada para que las lentes la vuelvan a dibujar con refracción.
                //    Con una hoja modal abierta, TalkBack solo recorre la hoja.
                Box(
                    Modifier.fillMaxSize().background(TT.Bg).backdropSource(backdrop)
                        .then(if (overlay.hasModal) Modifier.clearAndSetSemantics { } else Modifier),
                ) {
                    when {
                        // Cuenta de MIBUNKER (o seguir sin cuenta: la agenda queda solo en este móvil).
                        ac.needsAuth -> AuthScreen(ac)
                        // Introducción de thinktwice, que se puede omitir: la agenda y el temporizador no dependen de ella.
                        !tt.settings.onboardingDone -> OnboardingScreen(tt, ac)
                        else -> Screens(tt, ac, nav)
                    }
                }
                if (main) {
                    // 2) Cápsula flotante: lente sobre el contenido que pasa por detrás + iconos nítidos encima.
                    val density = LocalDensity.current
                    val imeOpen = WindowInsets.ime.getBottom(density) > 0
                    AnimatedVisibility(
                        visible = !imeOpen, modifier = Modifier.align(Alignment.BottomCenter),
                        enter = fadeIn(tween(Motion.tab)), exit = fadeOut(tween(Motion.tab)),
                    ) { Capsule(nav) }
                    Toast(nav)
                    GlobalSheets(tt, ac, nav)
                }
                // 3) Hojas (lente sobre la pantalla).
                OverlayLayer(overlay, modal = true)
            }
            // 4) Desplegables, por encima de todo: refractan la escena completa (pantalla, barra y hoja).
            CompositionLocalProvider(LocalBackdrop provides sceneAll) { OverlayLayer(overlay, modal = false) }
        }
    }
}

@Composable
private fun Screens(tt: AppState, ac: AcadState, nav: Nav) {
    val holder = rememberSaveableStateHolder()
    val reduce = LocalReduceMotion.current
    AnimatedContent(
        targetState = Triple(nav.tab, nav.depth, nav.top),
        transitionSpec = {
            when {
                reduce -> EnterTransition.None togetherWith ExitTransition.None
                nav.tabChange -> fadeIn(tween(Motion.tab)) togetherWith fadeOut(tween(Motion.tab))
                nav.forward -> (slideInHorizontally(tween(Motion.detail)) { it / 3 } + fadeIn(tween(Motion.detail))) togetherWith fadeOut(tween(Motion.detail / 2))
                else -> fadeIn(tween(Motion.detail / 2)) togetherWith (slideOutHorizontally(tween(Motion.detail)) { it / 3 } + fadeOut(tween(Motion.detail)))
            }
        },
        contentKey = { "${it.first}:${it.second}" }, label = "screens",
    ) { (tab, depth, dest) ->
        // Cada pantalla conserva su estado (día elegido, filtros, posición de lectura) al volver.
        holder.SaveableStateProvider("$tab:$depth:$dest") {
            Box(Modifier.fillMaxSize().background(TT.Bg)) {
                if (dest == null) when (tab) {
                    Tab.HOY -> HoyScreen(tt, ac)
                    Tab.AGENDA -> AgendaScreen(tt, ac)
                    Tab.ESTUDIO -> EstudioScreen(tt, ac)
                    Tab.HABITOS -> HabitosScreen(ac)
                    Tab.TT -> ThinktwiceScreen(tt)
                } else DetailHost(dest, tt, ac)
            }
        }
    }
}

@Composable
private fun DetailHost(dest: Dest, tt: AppState, ac: AcadState) {
    when (dest) {
        Dest.StudySession -> StudySessionScreen(tt, ac)
        is Dest.SubjectHistory -> SubjectHistoryScreen(ac, dest.subject)
        is Dest.SubjectGrades -> SubjectGradesScreen(ac, dest.subject)
        Dest.Routines -> RoutinesScreen(tt)
        Dest.Challenges -> ChallengesScreen(tt)
        Dest.Stats -> StatsScreen(tt)
        Dest.Diagnostics -> DiagnosticsScreen(tt)
        Dest.Messages -> MessagesScreen(tt)
        Dest.Templates -> TemplatesScreen(tt)
        Dest.Classify -> ClassifyScreen(tt)
        Dest.About -> AboutScreen()
        is Dest.RoutineEdit -> RoutineEditorScreen(tt, ac, dest)
        is Dest.ChallengeDetail -> ChallengeDetailScreen(tt, dest.id)
        Dest.LensLab -> LensLabScreen()
    }
}

@Composable
private fun GlobalSheets(tt: AppState, ac: AcadState, nav: Nav) {
    val opener = nav.lastOpener
    nav.studyRequest?.let { req -> StartStudySheet(tt, ac, req, opener) { nav.studyRequest = null } }
    if (nav.profileOpen) ProfileSheet(tt, ac, opener) { nav.profileOpen = false }
    nav.add?.let { k -> AddSheet(ac, k, opener) { nav.add = null } }
    when (nav.sheet) {
        SheetKind.Block -> BlockSheet(tt) { nav.sheet = null }
        SheetKind.Pause -> PauseSheet(tt) { nav.sheet = null }
        SheetKind.NewChallenge -> NewChallengeSheet(tt) { nav.sheet = null }
        null -> Unit
    }
    nav.openEvent?.let { id -> EventSheet(tt, ac, id, null) { nav.openEvent = null } }
    nav.openExam?.let { id -> ExamSheet(ac, id) { nav.openExam = null } }
    val summary by StudyController.summary.collectAsState()
    summary?.let { StudySummarySheet(it) { StudyController.dismissSummary() } }
}

private data class CapsuleItem(val tab: Tab, val on: ImageVector, val off: ImageVector)

/**
 * Cápsula inferior flotante con cinco destinos: lente sobre el contenido que pasa por detrás de su huella
 * completa (también entre los iconos). Una raya del horario cambia suavemente de dirección en el canto y
 * reaparece alineada al salir. Iconos y etiquetas se componen encima, nítidos y en posición fija.
 *
 * La selección es una segunda lente, más curvada, que usa la misma muestra de la escena (no se duplican
 * letras ni imágenes). Al cambiar de pestaña el extremo delantero avanza primero, la pieza se alarga en la
 * dirección del viaje y el trasero la alcanza al asentarse; un segundo toque la redirige desde donde esté.
 * Con movimiento reducido cambia de destino sin estirarse.
 */
@Composable
private fun Capsule(nav: Nav) {
    val items = listOf(
        CapsuleItem(Tab.HOY, Icons.Rounded.Today, Icons.Outlined.Today),
        CapsuleItem(Tab.AGENDA, Icons.Rounded.CalendarMonth, Icons.Outlined.CalendarMonth),
        CapsuleItem(Tab.ESTUDIO, Icons.Rounded.MenuBook, Icons.Outlined.MenuBook),
        CapsuleItem(Tab.HABITOS, Icons.Rounded.TaskAlt, Icons.Outlined.TaskAlt),
        CapsuleItem(Tab.TT, Icons.Rounded.HourglassTop, Icons.Outlined.HourglassEmpty),
    )
    val shape = CircleShape
    val density = LocalDensity.current
    val reduce = LocalReduceMotion.current
    val scene = LocalBackdrop.current
    val barLens = rememberLens()
    val selLens = rememberLens()
    var pos by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    val sel = items.indexOfFirst { it.tab == nav.tab }.coerceAtLeast(0)
    // Extremos de la selección, en unidades de pestaña.
    val lead = remember { androidx.compose.animation.core.Animatable(sel.toFloat()) }
    val tail = remember { androidx.compose.animation.core.Animatable(sel + 1f) }
    LaunchedEffect(sel, reduce) {
        if (reduce) { lead.snapTo(sel.toFloat()); tail.snapTo(sel + 1f); return@LaunchedEffect }
        val right = sel > lead.value
        // Delantero: rápido; trasero: algo más lento. Comparten unos 200–280 ms.
        val fast = androidx.compose.animation.core.spring<Float>(dampingRatio = 0.82f, stiffness = 900f)
        val slow = androidx.compose.animation.core.spring<Float>(dampingRatio = 0.9f, stiffness = 420f)
        launch { lead.animateTo(sel.toFloat(), if (right) slow else fast) }
        launch { tail.animateTo(sel + 1f, if (right) fast else slow) }
    }
    BoxWithConstraints(
        Modifier.fillMaxWidth().navigationBarsPadding()
            .padding(start = Dim.capsuleSide, end = Dim.capsuleSide, bottom = Dim.capsuleGap)
            .height(Dim.capsuleH)
            .onGloballyPositioned { pos = it.positionInRoot() }
            .drawBehind {
                val full = androidx.compose.ui.geometry.Rect(androidx.compose.ui.geometry.Offset.Zero, size)
                val radii = app.minibunker.glass.LensMath.Radii.all(size.height / 2f)
                softShadow(full, radii, if (TT.isDark) 0.28f else 0.12f, dy = 3.dp.toPx())
                // Barra: espesor en la orilla, interior casi a escala natural.
                barLens.draw(this, scene, pos, full, radii,
                    LensLook(AccentMaterial.lensTint(AccentMaterial.Kind.BAR), 0.7f, AccentMaterial.lensLight(), bezel = 16.dp.toPx(), disp = 4.dp.toPx()),
                    AccentMaterial.glassOpaque())
                // Selección: segunda lente sobre la misma escena, más curvada, con el acento concentrado
                // en el interior y desvanecido en todo el perímetro (contorno de grosor cero).
                val inset = 5.dp.toPx()
                val itemW = (size.width - 2 * inset) / items.size
                val l = inset + lead.value * itemW + 2.dp.toPx()
                val r = inset + tail.value * itemW - 2.dp.toPx()
                val selRect = androidx.compose.ui.geometry.Rect(minOf(l, r), inset, maxOf(l, r), size.height - inset)
                // Mismo tinte de la barra sin atenuar (no aparece costura en su borde); el acento se añade después.
                selLens.draw(this, scene, pos, selRect,
                    app.minibunker.glass.LensMath.Radii.all(selRect.height / 2f),
                    LensLook(AccentMaterial.lensTint(AccentMaterial.Kind.BAR), edgeFade = 0f, light = AccentMaterial.lensLight() * 1.3f,
                        bezel = selRect.height * 0.45f, disp = 5.dp.toPx()),
                    TT.Accent.copy(alpha = 0.5f))
                val acc = AccentMaterial.lensTint(AccentMaterial.Kind.SELECTION)
                val c = selRect.center
                scale(scaleX = 1f, scaleY = selRect.height / selRect.width, pivot = c) {
                    drawCircle(
                        Brush.radialGradient(0f to acc, 0.5f to acc.copy(alpha = acc.alpha * 0.7f), 0.85f to acc.copy(alpha = acc.alpha * 0.2f), 1f to Color.Transparent,
                            center = c, radius = selRect.width / 2f),
                        radius = selRect.width / 2f, center = c,
                    )
                }
                // Contraste local bajo las etiquetas: tinte neutro suave (no sobre la selección).
                if (!ThemeState.solid) items.indices.forEach { i ->
                    if (i == sel) return@forEach
                    val c = androidx.compose.ui.geometry.Offset(inset + (i + 0.5f) * itemW, size.height / 2f)
                    val rr = size.height * 0.55f
                    drawCircle(Brush.radialGradient(0f to TT.Bg.copy(alpha = 0.32f), 1f to Color.Transparent, center = c, radius = rr), rr, c)
                }
            }
            .padding(5.dp)
            .semantics { isTraversalGroup = true; contentDescription = "Navegación principal" },
    ) {
        val itemW = maxWidth / items.size
        // Etiquetas legibles con texto grande, sin desbordar en pantallas pequeñas («thinktwice» es la más larga).
        val base = if (itemW < 60.dp) 10f else 11f
        val labelSp = (base / density.fontScale * minOf(density.fontScale, 1.25f)).sp
        Row(Modifier.fillMaxSize()) {
            items.forEach { it ->
                val active = it.tab == nav.tab
                Column(
                    Modifier.weight(1f).fillMaxHeight().clip(shape)
                        .pressable(role = Role.Tab, scaleDown = false) { nav.select(it.tab) }
                        .semantics { selected = active; contentDescription = it.tab.label },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Icon(if (active) it.on else it.off, null, tint = if (active) TT.AccentText else TT.Text.copy(alpha = 0.86f), modifier = Modifier.size(22.dp))
                    Spacer(Modifier.height(2.dp))
                    Text(
                        it.tab.label, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                        style = Type.label.copy(fontSize = labelSp, lineHeight = labelSp * 1.2f, color = if (active) TT.AccentText else TT.Text.copy(alpha = 0.86f),
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                            shadow = if (ThemeState.solid) null else androidx.compose.ui.graphics.Shadow(TT.Bg.copy(alpha = 0.6f), blurRadius = 6f)),
                    )
                }
            }
        }
    }
}

@Composable
private fun BoxScope.Toast(nav: Nav) {
    val msg = nav.toast
    LaunchedEffect(msg) { if (msg != null) { delay(2600); nav.toast = null } }
    AnimatedVisibility(
        visible = msg != null, enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { it / 2 }, exit = fadeOut(tween(160)),
        modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = Dim.capsuleH + Dim.capsuleGap + 12.dp, start = 20.dp, end = 20.dp),
    ) {
        var last by remember { mutableStateOf("") }
        if (msg != null) last = msg
        Row(
            Modifier.clip(CircleShape).background(TT.Control).padding(horizontal = 16.dp, vertical = 12.dp)
                .semantics { liveRegion = LiveRegionMode.Polite },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.CheckCircle, null, tint = TT.Positive, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(last, style = Type.bodyMedium)
        }
    }
}
