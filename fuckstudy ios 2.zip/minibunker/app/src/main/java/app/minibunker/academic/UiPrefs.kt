package app.minibunker.academic

import app.minibunker.json.*

/** Apariencia (se sincroniza con la cuenta en el documento prefs, como la web). */
data class UiPrefs(
    val accent: String = "azul", val mode: String = "oscuro", val updated: Long = 0,
    /**
     * Intensidad del vidrio guardada por el usuario: 0 = más transparente, 1 = más tintado.
     * null = sin preferencia guardada: se usa el extremo cristalino ([GLASS_DEFAULT]).
     */
    val glassPref: Float? = null,
) {
    /** Intensidad efectiva. */
    val glass: Float get() = glassPref ?: GLASS_DEFAULT
    fun toJson(): JObj = linkedMapOf<String, Any?>("accent" to accent, "mode" to mode, "updated" to updated).apply {
        if (glassPref != null) put("glass", glassPref.toDouble())
    }
    companion object {
        val ACCENTS = listOf("azul" to "Azul", "lila" to "Lila", "rosa" to "Rosa", "verde" to "Verde", "turquesa" to "Turquesa",
            "melocoton" to "Melocotón", "coral" to "Coral", "dorado" to "Dorado")
        /** Extremo cristalino para quien no ha elegido nada. */
        const val GLASS_DEFAULT = 0f
        /**
         * [glassFallback]: la web de MIBUNKER no conoce «glass» y, al guardar sus preferencias, lo omite;
         * en ese caso se conserva la intensidad que ya había en el móvil (o ninguna, si no se había elegido).
         */
        fun from(o: JObj?, glassFallback: Float? = null): UiPrefs? = o?.let {
            UiPrefs(it.str("accent").takeIf { a -> ACCENTS.any { x -> x.first == a } } ?: "azul",
                it.str("mode").takeIf { m -> m in setOf("oscuro", "claro", "auto") } ?: "oscuro", it.long("updated"),
                (it.num("glass")?.toFloat() ?: glassFallback)?.coerceIn(0f, 1f))
        }
    }
}
