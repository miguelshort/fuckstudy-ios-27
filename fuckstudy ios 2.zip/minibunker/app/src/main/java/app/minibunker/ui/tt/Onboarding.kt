package app.minibunker.ui.tt

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import app.thinktwice.core.AppState
import app.thinktwice.data.Store
import app.thinktwice.system.Perms
import app.minibunker.ui.LocalResumeTick
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.*
import app.minibunker.ui.theme.*

private data class Intro(val icon: ImageVector, val title: String, val text: String)

private val intros = listOf(
    Intro(Icons.Rounded.School, "Estudia sin distracciones", "fuckstudy incluye thinktwice: al empezar a estudiar puedes proteger esos minutos y las apps que elijas quedarán en pausa hasta que termines el bloque."),
    Intro(Icons.Rounded.HourglassTop, "Una pausa antes de entrar", "Al abrir una app que elijas verás unos segundos de espera para decidir si de verdad quieres entrar."),
    Intro(Icons.Rounded.EventRepeat, "Bloqueos y rutinas", "Pon en pausa varias apps durante un rato o en franjas fijas, también ligadas a tus clases. Siempre con salida de emergencia. Tu uso del móvil se queda en este dispositivo."),
)

@Composable
fun OnboardingScreen(state: AppState, ac: app.minibunker.academic.AcadState) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    // Reutiliza el nombre del perfil (cuenta de MIBUNKER) si existe.
    var name by rememberSaveable { mutableStateOf(state.settings.name.ifBlank { ac.account?.name.orEmpty() }) }
    var apps by rememberSaveable { mutableStateOf(listOf<String>()) }
    var pause by rememberSaveable { mutableStateOf(true) }
    val reduce = LocalReduceMotion.current
    BackHandler(enabled = step > 0) { step-- }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Dim.screenH, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo(18.dp)
            Spacer(Modifier.weight(1f))
            // Omitir: la agenda y el temporizador funcionan igual; thinktwice se configura luego desde Perfil.
            Text(if (step < intros.size) "Omitir" else "Ahora no", style = Type.bodyMedium.copy(color = TT.TextSecondary),
                modifier = Modifier.clip(CircleShape).pressable {
                    Store.update { s -> s.copy(settings = s.settings.copy(name = s.settings.name.ifBlank { name.trim() }, onboardingDone = true)) }
                }.padding(12.dp))
        }
        AnimatedContent(step, Modifier.weight(1f), transitionSpec = {
            if (reduce) EnterTransition.None togetherWith ExitTransition.None
            else (slideInHorizontally(tween(Motion.detail)) { it / 4 } + fadeIn(tween(Motion.detail))) togetherWith fadeOut(tween(120))
        }, label = "onb") { s ->
            when {
                s < intros.size -> IntroPage(intros[s], s)
                s == intros.size -> SetupPage(name, { name = it }, apps.toSet(), { apps = it.toList() }, pause, { pause = it })
                else -> PermissionsPage()
            }
        }
        val last = step > intros.size
        PillButton(
            when { step < intros.size -> "Siguiente"; !last -> "Continuar"; else -> "Empezar" },
            {
                if (!last) step++
                else Store.update { s ->
                    s.copy(
                        settings = s.settings.copy(name = name.trim(), onboardingDone = true),
                        pausedApps = if (pause) apps.toSet() else s.pausedApps,
                        templates = s.templates.map { if (it.packages.isEmpty()) it.copy(packages = apps.toSet()) else it },
                    )
                }
            },
            Modifier.fillMaxWidth().padding(horizontal = Dim.screenH, vertical = 16.dp),
        )
    }
}

@Composable
private fun IntroPage(i: Intro, index: Int) {
    Column(Modifier.fillMaxSize().padding(horizontal = Dim.screenH), verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(TT.Control), contentAlignment = Alignment.Center) {
            Icon(i.icon, null, tint = TT.Text, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text(i.title, style = Type.screenTitle.copy(fontSize = Type.hero.fontSize * 0.75f, lineHeight = Type.hero.lineHeight * 0.8f))
        Spacer(Modifier.height(12.dp))
        Text(i.text, style = Type.body.copy(color = TT.TextSecondary))
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(intros.size) { Box(Modifier.size(if (it == index) 20.dp else 6.dp, 6.dp).clip(CircleShape).background(if (it == index) TT.Text else TT.Control)) }
        }
    }
}

@Composable
private fun SetupPage(name: String, onName: (String) -> Unit, apps: Set<String>, onApps: (Set<String>) -> Unit, pause: Boolean, onPause: (Boolean) -> Unit) {
    val installed by rememberInstalledApps()
    var query by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = Dim.screenH)) {
        item {
            Text("Prepara thinktwice", style = Type.screenTitle)
            Spacer(Modifier.height(16.dp))
            LabeledField("Tu nombre (opcional)", name, { onName(it.take(40)) }, help = "Solo se muestra en tu perfil.")
            Spacer(Modifier.height(24.dp))
            Text("¿Qué apps quieres controlar?", style = Type.section)
            Text("Puedes cambiarlas cuando quieras.", style = Type.secondary)
            Spacer(Modifier.height(12.dp))
            ListGroup {
                ListRow("Pausa de 15 s al abrirlas", "Tu primera función. Podrás usarlas 5 min tras la espera.", leading = { RowIcon(Icons.Rounded.HourglassTop) },
                    trailingSwitch = pause, onSwitch = onPause, switchLabel = "Pausa al abrirlas")
            }
            Spacer(Modifier.height(12.dp))
            LabeledField("Buscar", query, { query = it }, placeholder = "Nombre de la app")
            Spacer(Modifier.height(12.dp))
        }
        val list = installed
        if (list == null) item { Text("Cargando aplicaciones…", style = Type.secondary) }
        else items(list.filter { query.isBlank() || it.label.contains(query.trim(), true) }, key = { it.pkg }) { a ->
            val checked = a.pkg in apps
            Row(
                Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                    .pressable(role = Role.Checkbox, scaleDown = false) { onApps(if (checked) apps - a.pkg else apps + a.pkg) }
                    .padding(vertical = 6.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AppIcon(a.pkg); Spacer(Modifier.width(14.dp))
                Text(a.label, style = Type.bodyMedium, modifier = Modifier.weight(1f), maxLines = 2)
                Checkbox(checked, null, colors = CheckboxDefaults.colors(checkedColor = TT.Accent, uncheckedColor = TT.TextSecondary, checkmarkColor = TT.Bg))
            }
        }
    }
}

@Composable
private fun PermissionsPage() {
    val ctx = LocalContext.current
    val tick = LocalResumeTick.current
    val guard = remember(tick) { Perms.isGuardEnabled(ctx) }
    val usage = remember(tick) { Perms.hasUsageAccess(ctx) }
    var notif by remember(tick) { mutableStateOf(Perms.notificationsEnabled(ctx)) }
    var disclosure by remember { mutableStateOf(false) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notif = it }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = Dim.screenH)) {
        item {
            Text("Permisos", style = Type.screenTitle)
            Text("Te explicamos cada uno antes de pedirlo. Puedes continuar sin ellos: la agenda y el temporizador funcionan igual, y podrás activarlos al usar la función que los necesita.", style = Type.secondary)
            Spacer(Modifier.height(20.dp))
            PermStep("Mostrar pausas y bloqueos", "Servicio de accesibilidad de fuckstudy: solo sabe qué app se abre para mostrar tu pausa, tu bloqueo o la protección de tu estudio. No lee la pantalla ni lo que escribes.",
                guard, "Sin él: pausas y bloqueos desactivados.") { disclosure = true }
            PermStep("Ver tu uso del móvil", "Acceso a datos de uso: tiempo por app y día para tus estadísticas.",
                usage, "Sin él: estadísticas y retos de uso sin datos.") { Perms.open(ctx, Perms.usageAccessIntent(ctx)) }
            PermStep("Notificaciones", "Para ver el tiempo restante de tus sesiones y recordatorios opcionales.",
                notif, "Sin ellas: no verás la cuenta atrás fuera de la app.") {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else Perms.open(ctx, Perms.notificationSettingsIntent(ctx))
            }
        }
    }
    if (disclosure) ConfirmDialog(
        "Antes de activar el servicio",
        "fuckstudy usará la API de accesibilidad de Android únicamente para detectar el nombre de la app que pasa a primer plano y mostrar tu pausa, tu bloqueo o la protección de tu estudio (funciones de thinktwice). No lee contenido, mensajes ni texto, no es una herramienta para personas con discapacidad y no envía esos datos fuera del móvil. En la siguiente pantalla busca «fuckstudy» y actívalo. Puedes desactivarlo cuando quieras.",
        "Aceptar y abrir ajustes", danger = false,
        onConfirm = { disclosure = false; Perms.open(ctx, Perms.accessibilityIntent()) },
        onDismiss = { disclosure = false },
    )
}

@Composable
private fun PermStep(title: String, text: String, granted: Boolean, without: String, onGrant: () -> Unit) {
    TTCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = Type.cardTitle, modifier = Modifier.weight(1f))
            StatusDot(granted, if (granted) "Concedido" else "Pendiente")
        }
        Spacer(Modifier.height(4.dp))
        Text(text, style = Type.secondary)
        if (!granted) {
            Spacer(Modifier.height(6.dp))
            Text(without, style = Type.label)
            Spacer(Modifier.height(12.dp))
            SmallPill("Conceder", onGrant, tone = ButtonTone.Light)
        }
    }
    Spacer(Modifier.height(Dim.related))
}
