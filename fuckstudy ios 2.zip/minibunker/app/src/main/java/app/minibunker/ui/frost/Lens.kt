package app.minibunker.ui.frost

import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.minibunker.glass.LensMath
import app.minibunker.ui.theme.TT
import app.minibunker.ui.theme.ThemeState
import kotlin.math.roundToInt

/**
 * Lente de vidrio líquido (sustituye al desenfoque).
 *
 * Orden de composición de cada pieza: 1) la escena real ya dibujada en pantalla, 2) dentro de la silueta,
 * la misma zona de la escena vuelta a dibujar con la refracción (casi a escala natural en el centro,
 * desplazada perpendicularmente al canto y ampliada cerca de la curva), con el tinte del acento que se
 * atenúa hacia el perímetro, un reflejo corto en el lado iluminado y una sombra suave en el opuesto,
 * 3) el contenido propio (texto, iconos, campos, logo), nítido, encima.
 *
 * Radio de desenfoque: cero. La escena se toma de un [Backdrop] (capa compartida) con las coordenadas reales
 * de la pieza, así que al desplazar el contenido la muestra se mueve en el mismo fotograma.
 *
 * Rutas:
 *  - Android 13+ (API 33): sombreador AGSL ([LensShader]) aplicado como RenderEffect a la muestra.
 *  - Android 8–12: misma muestra dibujada por bandas concéntricas con la escala que produce el mismo
 *    desplazamiento en el centro de cada banda ([LensMath.bands]); el tinte, el reflejo y la sombra se dibujan aparte.
 *  - Contraste elevado ([ThemeState.solid]): sin refracción ni reflejos, base casi opaca.
 */
data class LensLook(
    /** Tinte (color y opacidad) en el interior. */
    val tint: Color,
    /** Cuánto se atenúa el tinte en el perímetro (0 = nada, 1 = desaparece en el canto). */
    val edgeFade: Float = 0.7f,
    /** Intensidad del reflejo del lado iluminado y de la sombra del opuesto. */
    val light: Float = 0.35f,
    /** Anchura de la franja curva y desplazamiento máximo (px). */
    val bezel: Float,
    val disp: Float,
    /** Punto de contacto (px locales) para el reflejo localizado; Unspecified si no hay. */
    val touch: Offset = Offset.Unspecified,
    /** 0..1: respuesta a la presión (reflejo cerca del dedo). */
    val press: Float = 0f,
)

/** Radios de las esquinas de una forma de Compose, en píxeles. */
fun DrawScope.radiiOf(shape: Shape, size: Size): LensMath.Radii = when (val o = shape.createOutline(size, layoutDirection, this)) {
    is Outline.Rounded -> o.roundRect.let { LensMath.Radii(it.topLeftCornerRadius.x, it.topRightCornerRadius.x, it.bottomRightCornerRadius.x, it.bottomLeftCornerRadius.x) }
    is Outline.Rectangle -> LensMath.Radii.all(0f)
    is Outline.Generic -> LensMath.Radii.all(minOf(size.width, size.height) / 4f)
    else -> LensMath.Radii.all(0f)
}

fun roundRectPath(rect: Rect, r: LensMath.Radii): Path = Path().apply {
    addRoundRect(RoundRect(rect, CornerRadius(r.tl), CornerRadius(r.tr), CornerRadius(r.br), CornerRadius(r.bl)))
}

/** Estado de una pieza de vidrio: su capa de muestra y, en Android 13+, su sombreador. */
class Lens internal constructor(val layer: GraphicsLayer) {
    private var shader: Any? = null

    /**
     * Dibuja la lente en [rect] (coordenadas locales del DrawScope). [rootPos]: posición del DrawScope en la raíz.
     * Si no hay escena (o hay contraste elevado), dibuja una superficie opaca del mismo tono.
     */
    fun draw(scope: DrawScope, scene: Backdrop?, rootPos: Offset, rect: Rect, radii: LensMath.Radii, look: LensLook, opaque: Color): Unit = with(scope) {
        val w = rect.width.roundToInt(); val h = rect.height.roundToInt()
        if (w < 2 || h < 2) return@with
        val path = roundRectPath(rect, radii)
        if (scene == null || ThemeState.solid) {
            drawPath(path, opaque)
            drawOutline(Outline.Generic(path), TT.GlassBorder, style = Stroke(1.dp.toPx()))
            return@with
        }
        @Suppress("UNUSED_VARIABLE") val v = scene.version // lectura: se redibuja cuando cambia la escena
        val spec = LensMath.Spec(look.bezel, look.disp)
        // 1) Muestra de la escena en las coordenadas reales de la pieza (sin desenfoque).
        layer.record(size = IntSize(w, h)) {
            translate(scene.origin.x - rootPos.x - rect.left, scene.origin.y - rootPos.y - rect.top) { drawLayer(scene.layer) }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            val sh = (shader as? RuntimeShader) ?: LensShader.create().also { shader = it }
            LensShader.set(sh, w.toFloat(), h.toFloat(), radii, spec, look)
            layer.renderEffect = LensShader.effect(sh)
            translate(rect.left, rect.top) { drawLayer(layer) }
        } else {
            layer.renderEffect = null
            // 2) Interior a escala natural y bandas del canto con la ampliación correspondiente.
            clipPath(path) { translate(rect.left, rect.top) { drawLayer(layer) } }
            LensMath.bands(w.toFloat(), h.toFloat(), spec).forEach { b ->
                val outer = roundRectPath(rect.deflate(b.outerInset), radii.inset(b.outerInset))
                val inner = roundRectPath(rect.deflate(b.innerInset), radii.inset(b.innerInset))
                val ring = Path().apply { op(outer, inner, PathOperation.Difference) }
                clipPath(ring) {
                    scale(b.scaleX, b.scaleY, pivot = rect.center) { translate(rect.left, rect.top) { drawLayer(layer) } }
                }
            }
            // 3) Tinte (más débil en el perímetro), reflejo y sombra.
            clipPath(path) {
                val bez = minOf(look.bezel, rect.minDimension / 2f) * 0.5f
                val core = roundRectPath(rect.deflate(bez), radii.inset(bez))
                drawPath(core, look.tint)
                val ring = Path().apply { op(path, core, PathOperation.Difference) }
                drawPath(ring, look.tint.copy(alpha = look.tint.alpha * (1f - look.edgeFade * 0.6f)))
                fallbackLight(rect, look)
            }
        }
    }

    /** Reflejo corto arriba a la izquierda y sombra suave abajo a la derecha (ruta sin sombreador). */
    private fun DrawScope.fallbackLight(rect: Rect, look: LensLook) {
        if (look.light <= 0f) return
        val r = rect.minDimension * 0.9f
        drawCircle(Brush.radialGradient(0f to Color.White.copy(alpha = look.light * 0.55f), 1f to Color.Transparent,
            center = Offset(rect.left + rect.width * 0.18f, rect.top), radius = r), r, Offset(rect.left + rect.width * 0.18f, rect.top))
        drawRect(Brush.verticalGradient(0.7f to Color.Transparent, 1f to Color.Black.copy(alpha = look.light * 0.35f), startY = rect.top, endY = rect.bottom),
            topLeft = rect.topLeft, size = rect.size)
        if (look.touch != Offset.Unspecified && look.press > 0f) {
            val c = rect.topLeft + look.touch; val tr = rect.minDimension * 0.6f
            drawCircle(Brush.radialGradient(0f to Color.White.copy(alpha = 0.22f * look.press), 1f to Color.Transparent, center = c, radius = tr), tr, c)
        }
    }
}

@Composable
fun rememberLens(): Lens { val l = androidx.compose.ui.graphics.rememberGraphicsLayer(); return remember(l) { Lens(l) } }

/** Sombra corta bajo una pieza flotante, sin desenfoque: tres contornos crecientes muy tenues. */
fun DrawScope.softShadow(rect: Rect, radii: LensMath.Radii, alpha: Float, dy: Float = 4.dp.toPx()) {
    if (alpha <= 0f) return
    for (i in 1..3) {
        val g = i * 2.dp.toPx()
        drawPath(roundRectPath(rect.inflate(g).translate(0f, dy), radii.let { LensMath.Radii(it.tl + g, it.tr + g, it.br + g, it.bl + g) }),
            Color.Black.copy(alpha = alpha / (i * 2.2f)))
    }
}

/**
 * Sombreador AGSL de la lente (Android 13+). Misma geometría que [LensMath.sample].
 * La entrada «scene» es la muestra de la escena del tamaño de la pieza; fuera de la silueta devuelve transparente.
 */
@RequiresApi(33)
object LensShader {
    const val AGSL = """
uniform shader scene;
uniform float2 size;
uniform float4 radii;
uniform float bezel;
uniform float disp;
uniform float4 tint;
uniform float edgeFade;
uniform float light;
uniform float2 touch;
uniform float press;

float sdBox(float2 p, float2 b, float4 r) {
    float rr = (p.x > 0.0) ? ((p.y > 0.0) ? r.z : r.y) : ((p.y > 0.0) ? r.w : r.x);
    rr = min(rr, min(b.x, b.y));
    float2 q = abs(p) - b + rr;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - rr;
}

half4 main(float2 xy) {
    float2 hs = size * 0.5;
    float2 p = xy - hs;
    float d = sdBox(p, hs, radii);
    float aa = clamp(0.5 - d, 0.0, 1.0);
    if (aa <= 0.0) { return half4(0.0); }
    float e = 1.0;
    float2 g = float2(sdBox(p + float2(e, 0.0), hs, radii) - sdBox(p - float2(e, 0.0), hs, radii),
                      sdBox(p + float2(0.0, e), hs, radii) - sdBox(p - float2(0.0, e), hs, radii));
    float gl = length(g);
    float2 n = (gl > 0.0001) ? g / gl : float2(0.0, 0.0);
    float t = clamp(1.0 + d / bezel, 0.0, 1.0);
    float k = t * t;
    float2 s = clamp(xy - n * (disp * k), float2(0.5, 0.5), size - float2(0.5, 0.5));
    float4 c = float4(scene.eval(s));

    float ta = tint.a * (1.0 - edgeFade * smoothstep(0.35, 1.0, t));
    float3 rgb = c.rgb * (1.0 - ta) + tint.rgb * ta;
    float alpha = c.a + ta * (1.0 - c.a);

    float2 L = normalize(float2(-0.45, -1.0));
    float ndl = dot(n, L);
    float rim = pow(clamp(ndl, 0.0, 1.0), 2.0) * pow(t, 6.0);
    float shade = pow(clamp(-ndl, 0.0, 1.0), 2.0) * pow(t, 4.0);
    rgb = rgb + float3(light * rim);
    rgb = rgb * (1.0 - light * 0.35 * shade);

    if (touch.x >= 0.0 && press > 0.0) {
        float2 dt = xy - touch;
        float rr = min(size.x, size.y) * 0.6;
        rgb = rgb + float3(0.22 * press * exp(-dot(dt, dt) / (rr * rr)));
    }
    rgb = clamp(rgb, 0.0, 1.0) * alpha;
    return half4(half3(rgb * aa), half(alpha * aa));
}
"""

    fun create(): RuntimeShader = RuntimeShader(AGSL)

    fun set(sh: RuntimeShader, w: Float, h: Float, r: LensMath.Radii, spec: LensMath.Spec, look: LensLook) {
        sh.setFloatUniform("size", w, h)
        sh.setFloatUniform("radii", r.tl, r.tr, r.br, r.bl)
        sh.setFloatUniform("bezel", maxOf(1f, spec.bezel))
        sh.setFloatUniform("disp", spec.safeDisp)
        sh.setFloatUniform("tint", look.tint.red, look.tint.green, look.tint.blue, look.tint.alpha)
        sh.setFloatUniform("edgeFade", look.edgeFade)
        sh.setFloatUniform("light", look.light)
        if (look.touch == Offset.Unspecified) sh.setFloatUniform("touch", -1f, -1f) else sh.setFloatUniform("touch", look.touch.x, look.touch.y)
        sh.setFloatUniform("press", look.press)
    }

    fun effect(sh: RuntimeShader): RenderEffect =
        android.graphics.RenderEffect.createRuntimeShaderEffect(sh, "scene").asComposeRenderEffect()
}
