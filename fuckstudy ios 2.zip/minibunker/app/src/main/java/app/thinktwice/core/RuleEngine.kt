package app.thinktwice.core

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Una restricción vigente: procede de una sesión de bloqueo o de una rutina. */
data class Restriction(
    val kind: Kind,
    val id: String,
    val name: String,
    val packages: Set<String>,
    val startMs: Long,
    val endMs: Long,
) {
    enum class Kind { SESSION, ROUTINE }
}

sealed interface Decision {
    data object Allow : Decision
    /** Pausa consciente: se puede continuar al terminar la espera. */
    data class Pause(val pkg: String) : Decision
    /** Restricción de thinktwice (sesión o rutina). [untilMs] tiene en cuenta restricciones encadenadas. */
    data class Block(val pkg: String, val sources: List<Restriction>, val untilMs: Long) : Decision
}

/**
 * Motor de reglas puro. Todas las decisiones se calculan a partir de marcas de tiempo
 * guardadas y de la zona horaria vigente en el momento de evaluar, nunca a partir de
 * un contador en memoria. Así sobreviven al cierre de la interfaz, a reinicios y a
 * cambios de hora o de zona.
 */
object RuleEngine {

    /**
     * Franja de la rutina que contiene [at], si existe. Las rutinas se definen en hora local
     * de pared: se evalúan con la zona actual (un viaje cambia la hora a la que se aplican).
     * Si fin <= inicio la franja cruza la medianoche y pertenece al día en que empieza.
     * Si fin == inicio la franja dura 24 h.
     */
    fun windowContaining(r: Routine, at: Long, zone: ZoneId): Pair<Long, Long>? {
        val today = Instant.ofEpochMilli(at).atZone(zone).toLocalDate()
        for (d in listOf(today.minusDays(1), today)) {
            val w = windowStartingOn(r, d, zone) ?: continue
            if (at >= w.first && at < w.second) return w
        }
        return null
    }

    fun windowStartingOn(r: Routine, d: LocalDate, zone: ZoneId): Pair<Long, Long>? {
        if (!startsOn(r, d)) return null
        val start = ZonedDateTime.of(d, LocalTime.of(r.startMin / 60, r.startMin % 60), zone)
        val endDate = if (r.endMin > r.startMin) d else d.plusDays(1)
        val end = ZonedDateTime.of(endDate, LocalTime.of(r.endMin / 60 % 24, r.endMin % 60), zone)
        val s = start.toInstant().toEpochMilli()
        val e = end.toInstant().toEpochMilli()
        return if (e > s) s to e else null
    }

    /** ¿Empieza una franja de [r] el día [d]? (rutinas semanales, puntuales, mensuales o anuales) */
    fun startsOn(r: Routine, d: LocalDate): Boolean {
        val anchor = r.anchorDay?.let { LocalDate.ofEpochDay(it) }
        if (anchor != null && d.isBefore(anchor)) return false
        return when (r.schedule) {
            Schedule.WEEKLY -> d.dayOfWeek.value in r.days
            Schedule.ONCE -> anchor != null && d == anchor
            Schedule.MONTHLY -> anchor != null && d.dayOfMonth == anchor.dayOfMonth
            Schedule.YEARLY -> anchor != null && d.dayOfMonth == anchor.dayOfMonth && d.month == anchor.month
        }
    }

    /** Restricciones vigentes en [at] (sesiones activas y rutinas activadas no suspendidas). */
    fun restrictionsAt(state: AppState, at: Long, zone: ZoneId): List<Restriction> {
        val out = mutableListOf<Restriction>()
        state.sessions.filter { it.isActive(at) }.forEach {
            out += Restriction(Restriction.Kind.SESSION, it.id, it.name, it.packages, it.startMs, it.endMs)
        }
        state.routines.filter { it.enabled && it.packages.isNotEmpty() }.forEach { r ->
            val w = windowContaining(r, at, zone) ?: return@forEach
            val skippedUntil = state.routineSkips[r.id]
            if (skippedUntil != null && skippedUntil > at) return@forEach
            out += Restriction(Restriction.Kind.ROUTINE, r.id, r.name, r.packages, w.first, w.second)
        }
        return out
    }

    /**
     * Momento en que [pkg] queda libre. Si al terminar una restricción empieza o sigue otra
     * (rutinas superpuestas o contiguas, sesión dentro de rutina…), se encadena: nunca se
     * libera la app mientras alguna regla siga vigente.
     */
    fun freeAt(state: AppState, pkg: String, now: Long, zone: ZoneId): Long {
        var t = now
        repeat(32) {
            val applying = restrictionsAt(state, t, zone).filter { pkg in it.packages }
            if (applying.isEmpty()) return t
            t = applying.maxOf { it.endMs }
        }
        return t
    }

    fun decide(state: AppState, pkg: String, now: Long, zone: ZoneId): Decision {
        val sources = restrictionsAt(state, now, zone).filter { pkg in it.packages }
        if (sources.isNotEmpty()) return Decision.Block(pkg, sources, freeAt(state, pkg, now, zone))
        if (pkg in state.pausedApps) {
            val allowed = state.allowances[pkg]
            return if (allowed != null && allowed > now) Decision.Allow else Decision.Pause(pkg)
        }
        return Decision.Allow
    }

    /** Próxima franja de rutina activada que aún no ha empezado (busca hasta ~13 meses por las anuales). */
    fun nextRoutineStart(state: AppState, now: Long, zone: ZoneId): Pair<Routine, Pair<Long, Long>>? {
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        var best: Pair<Routine, Pair<Long, Long>>? = null
        for (r in state.routines.filter { it.enabled }) {
            for (i in 0..400) {
                val w = windowStartingOn(r, today.plusDays(i.toLong()), zone) ?: continue
                if (w.first > now) {
                    if (best == null || w.first < best.second.first) best = r to w
                    break
                }
            }
        }
        return best
    }

    /** Instante de fin de la franja actual de la rutina (para la salida de emergencia). */
    fun currentWindowEnd(r: Routine, now: Long, zone: ZoneId): Long? = windowContaining(r, now, zone)?.second
}
